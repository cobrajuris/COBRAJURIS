-- ============================================================
-- CobraJuris — Schema PostgreSQL (Supabase)
-- Rodar no SQL Editor do Supabase ou via migration (supabase db push)
-- Multi-tenant por empresa, com RLS.
-- ============================================================

-- EMPRESAS (tenants)
create table empresas (
  id uuid primary key default gen_random_uuid(),
  razao_social text not null,
  cnpj text unique,
  email_contato text,
  assinatura_padrao text,            -- substitui {{empresa}} nas mensagens
  plano text not null default 'empresa',  -- empresa | pro | enterprise
  limite_disparos_dia int not null default 80,
  janela_inicio time not null default '08:00',
  janela_fim time not null default '20:00',
  criado_em timestamptz not null default now()
);

-- USUÁRIOS (ligados ao Supabase Auth)
create table usuarios (
  id uuid primary key references auth.users(id) on delete cascade,
  empresa_id uuid not null references empresas(id) on delete cascade,
  nome text not null,
  papel text not null default 'financeiro',  -- admin | financeiro | leitura
  criado_em timestamptz not null default now()
);

-- CLIENTES (devedores)
create table clientes (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references empresas(id) on delete cascade,
  nome text not null,
  documento text,                    -- CPF ou CNPJ
  telefone text,                     -- WhatsApp/SMS
  email text,
  canal_preferido text not null default 'whatsapp',  -- whatsapp | sms | email
  criado_em timestamptz not null default now()
);
create index on clientes (empresa_id);
create unique index clientes_doc_unico on clientes (empresa_id, documento) where documento is not null;

-- FATURAS (débitos)
create table faturas (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references empresas(id) on delete cascade,
  cliente_id uuid not null references clientes(id) on delete cascade,
  numero text not null,              -- ex.: FAT-2026-0001 (da planilha ou gerado)
  valor numeric(12,2) not null,
  vencimento date,
  parcela text,                      -- ex.: "3/12"
  status text not null default 'pending',
  -- pending (a vencer) | overdue (em atraso) | sent (cobrança enviada)
  -- scheduled (agendado) | paid (quitado)
  pago_em timestamptz,
  importacao_id uuid,                -- lote de importação de origem
  criado_em timestamptz not null default now(),
  unique (empresa_id, numero)
);
create index on faturas (empresa_id, status);
create index on faturas (cliente_id);

-- MODELOS DE MENSAGEM
create table modelos (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references empresas(id) on delete cascade,
  nome text not null,
  canal text not null default 'whatsapp',
  tom text,                          -- Cordial | Formal | Conciliador
  assunto text,                      -- só e-mail
  corpo text not null,               -- com variáveis {{nome}} {{valor}} {{fatura}} {{vencimento}} {{dias}} {{empresa}} {{cnpj}} {{pix_copia_cola}} {{link_acordo}} {{prazo_limite}} {{valor_desconto}}
  ativo boolean not null default true,
  usos int not null default 0,
  criado_em timestamptz not null default now()
);

-- RÉGUAS (agendamentos) — executadas pelo n8n
create table reguas (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references empresas(id) on delete cascade,
  nome text not null,
  modelo_id uuid not null references modelos(id),
  canal text not null default 'whatsapp',
  hora time not null default '09:00',
  dias_semana int[] not null default '{1,3,5}',   -- 0=Dom … 6=Sáb
  filtro_status text[] not null default '{overdue}',  -- quais faturas entram
  filtro_dias_atraso_min int default 0,
  status text not null default 'ativo',           -- ativo | pausado
  criado_em timestamptz not null default now()
);

-- MENSAGENS (conversa por cliente; todo disparo grava aqui)
create table mensagens (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references empresas(id) on delete cascade,
  cliente_id uuid not null references clientes(id) on delete cascade,
  fatura_id uuid references faturas(id) on delete set null,
  regua_id uuid references reguas(id) on delete set null,
  modelo_id uuid references modelos(id) on delete set null,
  direcao text not null default 'out',            -- out (empresa→cliente) | in (resposta)
  canal text not null,
  corpo text not null,                            -- texto final, variáveis já resolvidas
  status text not null default 'queued',          -- queued | sent | delivered | read | failed
  provider_message_id text,                       -- id na API do canal (p/ webhooks de status)
  enviado_em timestamptz,
  criado_em timestamptz not null default now()
);
create index on mensagens (empresa_id, cliente_id, criado_em);

-- NOTIFICAÇÕES (sino)
create table notificacoes (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references empresas(id) on delete cascade,
  tipo text not null,                -- paid | reply | sent | alert
  titulo text not null,
  texto text,
  lida boolean not null default false,
  criado_em timestamptz not null default now()
);

-- IMPORTAÇÕES (lotes de planilha — arquivo no Supabase Storage)
create table importacoes (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references empresas(id) on delete cascade,
  usuario_id uuid references usuarios(id),
  arquivo_path text not null,        -- caminho no bucket 'planilhas'
  arquivo_nome text,
  linhas_total int,
  linhas_importadas int,
  linhas_duplicadas int,
  status text not null default 'processando',  -- processando | concluida | erro
  criado_em timestamptz not null default now()
);

-- Atualização automática de status overdue (rodar diariamente via pg_cron ou n8n)
create or replace function marcar_vencidas() returns void language sql as $$
  update faturas set status = 'overdue'
  where status in ('pending','sent','scheduled')
    and vencimento is not null and vencimento < current_date;
$$;

-- ================= RLS (Row Level Security) =================
alter table empresas      enable row level security;
alter table usuarios      enable row level security;
alter table clientes      enable row level security;
alter table faturas       enable row level security;
alter table modelos       enable row level security;
alter table reguas        enable row level security;
alter table mensagens     enable row level security;
alter table notificacoes  enable row level security;
alter table importacoes   enable row level security;

create or replace function minha_empresa() returns uuid language sql stable as $$
  select empresa_id from usuarios where id = auth.uid()
$$;

create policy tenant_empresas on empresas for all using (id = minha_empresa());
create policy tenant_usuarios on usuarios for all using (empresa_id = minha_empresa());
create policy tenant_clientes on clientes for all using (empresa_id = minha_empresa());
create policy tenant_faturas on faturas for all using (empresa_id = minha_empresa());
create policy tenant_modelos on modelos for all using (empresa_id = minha_empresa());
create policy tenant_reguas on reguas for all using (empresa_id = minha_empresa());
create policy tenant_mensagens on mensagens for all using (empresa_id = minha_empresa());
create policy tenant_notificacoes on notificacoes for all using (empresa_id = minha_empresa());
create policy tenant_importacoes on importacoes for all using (empresa_id = minha_empresa());

-- O backend NestJS e o n8n usam a SERVICE_ROLE key (bypassa RLS) — nunca expor no frontend.

-- Storage: criar bucket privado 'planilhas' no Supabase Storage
-- (Dashboard → Storage → New bucket → 'planilhas', private)
