# CobraJuris — Automação com n8n

O n8n roda no Railway/Coolify ao lado do NestJS e executa **os disparos e as réguas**. O NestJS decide *o que* enviar; o n8n cuida de *entregar* (com cadência segura) e devolver status.

## Workflow 1 — Disparo imediato (webhook)
**Trigger:** Webhook `POST /webhook/disparo` (chamado pelo NestJS ao criar mensagens `queued`).
1. **Postgres node** — busca mensagens `status='queued'` do lote.
2. **Loop com cadência humanizada** — Wait aleatório de 8–25s entre mensagens (proteção antiban WhatsApp).
3. **Switch por canal:**
   - **WhatsApp** → HTTP Request para a API escolhida (WhatsApp Cloud API oficial ou Evolution API self-hosted no mesmo Railway/Coolify).
   - **SMS** → Twilio/Zenvia node.
   - **E-mail** → SMTP node (ou Resend/SendGrid).
4. **Postgres node** — atualiza `mensagens.status='sent'`, `enviado_em=now()`, `provider_message_id`.
5. **Error branch** — marca `failed` e cria `notificacoes` tipo `alert`.

## Workflow 2 — Réguas agendadas (cron)
**Trigger:** Schedule a cada 15 min.
1. Busca `reguas` com `status='ativo'` cujo `hora`/`dias_semana` batem com o horário atual **e** dentro da janela da empresa (`janela_inicio`–`janela_fim`).
2. Para cada régua: busca faturas que casam com `filtro_status`/`filtro_dias_atraso_min`, respeitando `limite_disparos_dia` da empresa (conta `mensagens` do dia).
3. Chama `POST /v1/disparos` no NestJS (com service token) — que resolve variáveis e enfileira → cai no Workflow 1.

## Workflow 3 — Status e respostas (webhooks dos provedores)
**Trigger:** Webhook por canal (WhatsApp Cloud API webhook, Twilio status callback, webhook do provedor de e-mail).
1. Normaliza o payload → { provider_message_id, novo_status | resposta_texto }.
2. Chama `POST /v1/disparos/webhook-status` no NestJS.
3. Resposta recebida (`direcao:'in'`) gera notificação `reply` no sino; **"SAIR"** remove o cliente das réguas (opt-out).

## Workflow 4 — Manutenção diária (cron 06:00)
1. `select marcar_vencidas();` (faturas vencidas → `overdue`).
2. Recalcula dias de atraso para os filtros das réguas.
3. (Opcional) resumo diário por e-mail para a empresa.

## Proteções antiban (WhatsApp) já previstas no design
- Cadência com jitter (Workflow 1, passo 2)
- Janela de horário + limite diário por empresa (tabela `empresas`)
- Pausa automática da régua se taxa de `failed` subir (adicionar IF no Workflow 1 error branch → `reguas.status='pausado'` + notificação)
- Opt-out "SAIR" (Workflow 3)
