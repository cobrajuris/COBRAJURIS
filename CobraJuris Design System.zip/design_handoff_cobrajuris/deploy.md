# CobraJuris — Deploy

## Visão geral
```
[Next.js @ Vercel] ──HTTPS──> [NestJS @ Railway/Coolify] ──SQL──> [Supabase Postgres]
        │                            │        ▲                        │
        └── Supabase Auth (JWT) ─────┘        │                 [Supabase Storage]
                                     [n8n @ Railway/Coolify]  (bucket 'planilhas')
```

## 1. Supabase
1. Criar projeto em supabase.com → região São Paulo (sa-east-1).
2. SQL Editor → colar e rodar `schema.sql`.
3. Storage → criar bucket privado **`planilhas`**.
4. Auth → habilitar Email/Password. Criar o primeiro usuário e inserir a linha correspondente em `usuarios` + `empresas`.
5. Guardar: `SUPABASE_URL`, `SUPABASE_ANON_KEY` (frontend), `SUPABASE_SERVICE_ROLE_KEY` (só backend/n8n).

## 2. Backend NestJS (Railway ou Coolify)
- Deploy do repositório NestJS (Dockerfile ou buildpack Node 20).
- Variáveis: ver `.env.example`.
- Healthcheck `GET /health`. Porta padrão 3000.

## 3. n8n (Railway ou Coolify)
- Imagem oficial `n8nio/n8n`. Persistir volume `/home/node/.n8n`.
- Variáveis: `N8N_ENCRYPTION_KEY`, `WEBHOOK_URL=https://n8n.<dominio>`, credenciais Postgres (host do Supabase, usar connection pooling porta 6543).
- Importar os 4 workflows de `n8n-flows.md`.

## 4. Frontend Next.js (Vercel)
- Importar o repositório → framework Next.js detectado automaticamente.
- Variáveis: `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `NEXT_PUBLIC_API_URL=https://api.<dominio>/v1`.
- Domínio: `app.cobrajuris.com.br` (frontend) · `api.cobrajuris.com.br` (NestJS) · `n8n.cobrajuris.com.br` (n8n, proteger com auth básica).

## Ordem de implementação sugerida (para Claude Code)
1. Supabase: rodar `schema.sql`, criar bucket, seed de 1 empresa + usuário.
2. NestJS: módulos auth (validação JWT Supabase) → clientes/faturas → modelos (com preview de variáveis) → disparos (mock de envio) → importações → relatórios.
3. Next.js: layout (sidebar/topbar do protótipo em Tailwind) → login → clientes → dashboard → mensagens → agendamentos → importar → relatórios → configurações.
4. n8n: Workflow 1 com um provedor de teste, depois réguas e webhooks.
5. Trocar mock de envio pelo provedor real de WhatsApp (Cloud API ou Evolution API).
