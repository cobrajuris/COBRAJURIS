# Handoff: CobraJuris — Plataforma de Cobrança para Empresas

## Overview
CobraJuris é uma plataforma SaaS de cobrança automatizada para empresas (ex.: distribuidoras, autopeças/peças de caminhão, comércios, serviços). A empresa importa uma planilha de clientes inadimplentes (Excel/CSV) e o sistema dispara mensagens de cobrança por **WhatsApp, SMS e E-mail** em réguas agendadas, com modelos de mensagem, conversa por cliente, painel de indicadores e relatório mensal em Excel.

Este pacote entrega o protótipo navegável completo + a arquitetura de produção na stack escolhida pelo cliente.

## Stack alvo (definida pelo cliente)
| Camada | Tecnologia |
|---|---|
| Frontend | **Next.js** (App Router) + React + **Tailwind CSS** |
| Backend | **NestJS** (REST API) |
| Banco de dados | **PostgreSQL via Supabase** |
| Armazenamento | **Supabase Storage** (planilhas importadas, anexos) |
| Automação / disparos | **n8n** (réguas, envio WhatsApp/SMS/E-mail) |
| Hospedagem | **Vercel** (frontend) · **Railway ou Coolify** (NestJS + n8n) |

## About the Design Files
Os arquivos em `prototype/` são **referências de design em HTML** — um protótipo funcional (React via Babel, estado em localStorage) que mostra o visual e o comportamento pretendidos. **Não é código de produção para copiar diretamente.** A tarefa é **recriar estas telas em Next.js + Tailwind**, consumindo a API NestJS descrita em `api-spec.md`, com os dados no Postgres conforme `schema.sql`.

## Fidelity
**High-fidelity (hifi).** Cores, tipografia, espaçamento, estados e microinterações são finais. Recriar pixel-perfect usando Tailwind (o mapa de tokens → Tailwind está em "Design Tokens" abaixo).

## Screens / Views
Todas as telas existem no protótipo (`prototype/index.html` + um `.jsx` por tela):

1. **Login** (`LoginScreen.jsx`) — split: painel de marca verde-900 à esquerda (headline, stats), formulário à direita. Rota Next.js: `/login`. Auth: Supabase Auth (e-mail/senha).
2. **Painel** (`DashboardScreen.jsx`) — 4 StatCards (A receber, Recuperado, Em atraso, Taxa de quitação — todos derivados do banco), gráfico de barras empilhadas (situação financeira), tabela de cobranças recentes, atividade recente, botão "Disparar para todos". Rota: `/` (dashboard).
3. **Devedores/Clientes** (`DevedoresScreen.jsx`) — tabela com filtros por status (chips com contagem), multi-seleção com barra de ações em massa (Disparar agora, Agendar, **Limpar** com modal de confirmação), busca, novo devedor (modal), exportar CSV, clique no nome abre a **Conversa**. Rota: `/clientes`.
4. **Conversa** (`ChatDrawer.jsx`) — drawer lateral estilo WhatsApp por cliente: histórico de mensagens enviadas/recebidas, envio livre ou por modelo (variáveis resolvidas), faixa com débito/status. 
5. **Detalhe do devedor** (`DevedorDetail.jsx`) — drawer com KPIs do débito, contato, timeline, ações (Registrar pagamento, Abrir conversa).
6. **Importar** (`ImportacaoScreen.jsx`) — fluxo 3 passos: upload (drag&drop, .xlsx/.csv) → mapeamento de colunas com autodetecção e amostra → confirmação. Em produção: upload vai ao **Supabase Storage**, parsing no backend (NestJS), linhas viram registros `clientes` + `faturas`. Rota: `/importar`.
7. **Mensagens** (`MensagensScreen.jsx`) — biblioteca de modelos (criar/duplicar/ativar/excluir), editor com gavetas de variáveis ("Dados do devedor" e "Facilitar pagamento": `{{pix_copia_cola}}`, `{{link_acordo}}`, `{{prazo_limite}}`), preview por canal (bolha WhatsApp / e-mail). Rota: `/mensagens`.
8. **Agendamentos** (`AgendamentosScreen.jsx`) — cards de réguas (dias da semana, hora, canal, próximo disparo, pausar/retomar/excluir) + compositor de nova régua. Em produção as réguas viram **workflows n8n** (ver `n8n-flows.md`). Rota: `/agendamentos`.
9. **Relatórios** (`RelatoriosScreen.jsx`) — KPIs do período, desempenho por canal, recuperação por mês, ranking de modelos, seletor de mês + **Baixar Excel** (relatório .xls branded verde). Rota: `/relatorios`.
10. **Configurações** (`SettingsScreen.jsx`) — tela em **tema escuro** com acento verde-lodo: dados da empresa, canais (toggles WhatsApp/SMS/E-mail), janela de horários/limite diário, aparência (tema escuro/claro, cor de destaque). Rota: `/configuracoes`.

## Interactions & Behavior
- Navegação por sidebar fixa (ativa = fundo green-50, texto green-700); wordmark clicável → dashboard.
- Toasts (canto inferior direito, 3,8s) para toda ação de escrita.
- Modais de confirmação para ações destrutivas (excluir devedores selecionados).
- Busca global no topbar com autocomplete (nome/CPF-CNPJ/fatura) → abre detalhe.
- Sino de notificações com contador de não lidas e "Marcar lidas".
- Hover em cards: borda verde acesa + glow (`box-shadow: 0 0 0 1px #1B8761, 0 0 22px -4px rgba(27,135,97,.45)`) + `translateY(-3px)`.
- Disparo (individual, em massa ou "para todos") grava mensagem na conversa do cliente e muda status → `sent`.

## State Management (produção)
- Server state: React Query (TanStack) consumindo a API NestJS.
- Auth/session: Supabase Auth no Next.js (middleware) + JWT validado no NestJS.
- O protótipo usa um store observável em `prototype/store.jsx` — ler para entender TODAS as mutações e regras de negócio (dispatch, markPaid, importação, dedup por fatura, KPIs derivados em `cjKpis()`).

## Design Tokens
Fonte da verdade: `tokens/` no design system (copiado em `design-tokens.css`). Principais:
- **Cores**: primária `#0F6E4E` (green-600); hover `#0B5640`; vivo `#1B8761`; fundos suaves `#ECF6F1`; hero/CTA escuro `#073026` (green-900); texto `#0E1B17`/`#2B3A34`/`#5B6B64`; borda `#DEE4E0`; canvas `#F6F8F7`; latão raro `#BE9233`. Estados: quitado `#0B5640`/`#E7F6EE`, a vencer `#7A5210`/`#FBF1DD`, atraso `#7A241E`/`#FBEAE8`, enviado `#173A5C`/`#E8F0F8`. WhatsApp `#25D366`/`#075E54`.
- **Tipografia**: Outfit 700 (display/títulos, tracking -0.02em) · Work Sans 400/700 (UI/texto) · IBM Plex Mono (valores R$). Google Fonts.
- **Raio**: sm 6px · md 10px · lg 16px · xl 20px · full 999px. **Sombras** suaves. **Grid** 4px.
- Tailwind: estender `theme.colors.green` com a escala acima, `fontFamily.display = Outfit`, `fontFamily.sans = Work Sans`, `fontFamily.mono = IBM Plex Mono`.

## Assets
- Sem logo desenhado — **wordmark tipográfico**: "Cobra" em ink-900 + "Juris" em green-600, Outfit bold.
- Ícones: estilo Lucide, stroke 2px (usar `lucide-react` no Next.js; o protótipo tem o subset em `prototype/icons.jsx`).

## Files
- `prototype/` — protótipo completo (index.html + telas .jsx + app.css + store.jsx + data.jsx)
- `design-tokens.css` — tokens CSS do design system
- `schema.sql` — schema PostgreSQL/Supabase pronto para rodar (com RLS)
- `api-spec.md` — endpoints NestJS
- `n8n-flows.md` — automação de disparos
- `deploy.md` — Vercel + Railway/Coolify + variáveis de ambiente
- `.env.example` — variáveis de ambiente
