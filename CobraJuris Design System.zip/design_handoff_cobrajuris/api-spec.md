# CobraJuris — Especificação da API (NestJS)

Base: `https://api.<dominio>/v1` · Auth: `Authorization: Bearer <JWT do Supabase Auth>`.
O NestJS valida o JWT (JWKS do Supabase) e resolve `empresa_id` do usuário. Módulos sugeridos: `auth`, `clientes`, `faturas`, `modelos`, `reguas`, `mensagens`, `importacoes`, `relatorios`, `notificacoes`, `disparos`.

## Clientes
- `GET /clientes?status=&busca=&page=` — lista com filtros (status agregado da pior fatura) e busca (nome/documento/nº fatura)
- `POST /clientes` — { nome, documento?, telefone?, email?, canal_preferido? } (+ fatura inicial opcional)
- `PATCH /clientes/:id`
- `DELETE /clientes` — body { ids: uuid[] } (exclusão em massa — a UI confirma antes)

## Faturas
- `GET /faturas?cliente_id=&status=`
- `POST /faturas` · `PATCH /faturas/:id`
- `POST /faturas/:id/pagar` — marca `paid`, gera notificação tipo `paid`

## Modelos
- `GET /modelos` · `POST /modelos` · `PATCH /modelos/:id` · `DELETE /modelos/:id`
- `POST /modelos/:id/duplicar`
- `POST /modelos/preview` — { modelo_id | corpo, cliente_id, fatura_id } → corpo com variáveis resolvidas
  - Variáveis: nome, valor, fatura, vencimento, dias, empresa, cnpj, prazo_limite (hoje+5 dias úteis), valor_desconto, pix_copia_cola (payload EMV BR Code), link_acordo

## Réguas
- `GET /reguas` · `POST /reguas` · `PATCH /reguas/:id` (pausar = status:'pausado') · `DELETE /reguas/:id`
- Criar/atualizar régua deve sincronizar o agendamento no n8n (ver n8n-flows.md)

## Disparos
- `POST /disparos` — { fatura_ids?: uuid[], todos_em_aberto?: boolean, modelo_id?, corpo_livre? }
  1. resolve variáveis por cliente/fatura; 2. insere `mensagens` status `queued`;
  3. dispara webhook do n8n para envio; 4. faturas → `sent`; 5. notificação agregada
- `POST /disparos/webhook-status` — callback do n8n/provedores: atualiza `mensagens.status` (delivered/read/failed) e grava respostas (`direcao:'in'` + notificação `reply`)

## Mensagens (conversa)
- `GET /clientes/:id/mensagens` — thread completa
- `POST /clientes/:id/mensagens` — envio avulso pelo chat

## Importações
- `POST /importacoes/upload` — multipart; salva no bucket `planilhas` (Supabase Storage), cria registro
- `POST /importacoes/:id/analisar` — parse (SheetJS/exceljs) → { headers, amostra, mapeamento_sugerido }
- `POST /importacoes/:id/confirmar` — { mapeamento, canal_padrao, ignorar_duplicados } → cria clientes+faturas (dedup por `numero`), retorna contagens

## Relatórios
- `GET /relatorios/kpis?mes=` — a_receber, recuperado, em_atraso, taxa_quitacao (mesma lógica de `cjKpis()` no protótipo)
- `GET /relatorios/canais?mes=` · `GET /relatorios/recuperacao-mensal?ano=`
- `GET /relatorios/excel?mes=&ano=` — gera o .xls branded (portar `baixarRelatorioExcel()` de `prototype/RelatoriosScreen.jsx` para o backend com exceljs)

## Notificações
- `GET /notificacoes` · `POST /notificacoes/marcar-lidas`

## Empresa / Configurações
- `GET /empresa` · `PATCH /empresa` — dados, assinatura, janela de disparo, limite diário, canais ativos
