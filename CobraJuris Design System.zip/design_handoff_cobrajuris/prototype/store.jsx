/* CobraJuris — store central observável com persistência em localStorage.
   Toda a aplicação lê/escreve aqui; as telas re-renderizam via useCJ().
   Carrega DEPOIS de data.jsx (usa CJ_DEVEDORES/CJ_TEMPLATES/... como seed). */

const CJStore = (function () {
  const KEY = "cobrajuris.state.v5";

  function seed() {
    return {
      session: { authed: false, user: { nome: "Helena Martins", escritorio: "Aurora Peças & Diesel", iniciais: "HM" } },
      devedores: CJ_DEVEDORES.map((d) => ({ ...d })),
      templates: CJ_TEMPLATES.map((t) => ({ ...t })),
      agendamentos: CJ_AGENDAMENTOS.map((a) => ({ ...a, dias: [...a.dias] })),
      notifs: CJ_NOTIFS.map((n) => ({ ...n })),
      atividade: CJ_ATIVIDADE.map((a) => ({ ...a })),
      conversas: {},
    };
  }

  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return null;
      const s = JSON.parse(raw);
      if (!s || !Array.isArray(s.devedores)) return null;
      if (!s.session) s.session = seed().session;
      if (!s.conversas) s.conversas = {};
      return s;
    } catch (e) { return null; }
  }

  let state = load() || seed();
  const listeners = new Set();

  function persist() { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {} }
  function emit() { listeners.forEach((l) => l()); }
  function patch(part) { state = { ...state, ...part }; persist(); emit(); }
  function uid(prefix) { return prefix + "-" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5); }
  function nowHora() { return new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }); }
  function firstName(nome) { return (nome || "").replace(/\b(LTDA|ME|S\/A|EIRELI)\b/gi, "").trim().split(/\s+/)[0] || nome; }

  const api = {
    getState: () => state,
    subscribe(l) { listeners.add(l); return () => listeners.delete(l); },
    resetDemo() { state = seed(); state.session.authed = true; persist(); emit(); },

    // ---- sessão
    login(user) { patch({ session: { ...state.session, authed: true, ...(user ? { user } : {}) } }); },
    logout() { patch({ session: { ...state.session, authed: false } }); },

    // ---- devedores
    addDevedores(list) {
      const existing = new Set(state.devedores.map((d) => d.id));
      const novos = list.filter((d) => !existing.has(d.id));
      patch({ devedores: [...novos, ...state.devedores] });
      return novos.length;
    },
    addDevedor(d) {
      const novo = { id: d.id || uid("FAT-2026"), parcelas: "—", dias: 0, status: "pending", canal: "whatsapp", ultimo: "Agora", tel: "", ...d };
      patch({ devedores: [novo, ...state.devedores] });
      return novo;
    },
    removeDevedor(id) { patch({ devedores: state.devedores.filter((d) => d.id !== id) }); },
    updateDevedor(id, p) { patch({ devedores: state.devedores.map((d) => (d.id === id ? { ...d, ...p } : d)) }); },
    dispatch(ids) {
      const s = new Set(ids);
      const hora = nowHora();
      const conv = { ...state.conversas };
      state.devedores.forEach((d) => {
        if (s.has(d.id) && d.status !== "paid") {
          const prev = conv[d.id] || cjSeedConversa(d);
          const txt = `Olá ${firstName(d.nome)}, consta em aberto a fatura ${d.id} no valor de ${CJ_FMT(d.valor)}. Solicitamos a regularização ou contato para acordo.`;
          conv[d.id] = [...prev, { id: uid("m"), dir: "out", canal: d.canal, texto: txt, hora, status: "sent" }];
        }
      });
      const devedores = state.devedores.map((d) => (s.has(d.id) && d.status !== "paid" ? { ...d, status: "sent", ultimo: "Agora" } : d));
      patch({ devedores, conversas: conv });
    },
    // ---- conversas
    ensureConversa(d) {
      if (state.conversas[d.id]) return state.conversas[d.id];
      const msgs = cjSeedConversa(d);
      patch({ conversas: { ...state.conversas, [d.id]: msgs } });
      return msgs;
    },
    sendMensagem(id, msg) {
      const d = state.devedores.find((x) => x.id === id);
      const prev = state.conversas[id] || (d ? cjSeedConversa(d) : []);
      const m = { id: uid("m"), dir: "out", canal: (d && d.canal) || "whatsapp", hora: nowHora(), status: "sent", ...msg };
      const conversas = { ...state.conversas, [id]: [...prev, m] };
      const devedores = state.devedores.map((x) => (x.id === id && x.status !== "paid" ? { ...x, status: "sent", ultimo: "Agora" } : x));
      patch({ conversas, devedores });
      return m;
    },
    receberMensagem(id, texto) {
      const d = state.devedores.find((x) => x.id === id);
      const prev = state.conversas[id] || (d ? cjSeedConversa(d) : []);
      const m = { id: uid("m"), dir: "in", canal: (d && d.canal) || "whatsapp", hora: nowHora(), status: "read", texto };
      patch({ conversas: { ...state.conversas, [id]: [...prev, m] } });
      if (d) api.pushNotif({ canal: d.canal, tipo: "reply", titulo: "Resposta recebida", texto: `${d.nome}: “${texto.slice(0, 40)}…”` });
    },
    markPaid(id) {
      const d = state.devedores.find((x) => x.id === id);
      api.updateDevedor(id, { status: "paid", dias: 0, ultimo: "Agora" });
      if (d) { api.pushNotif({ canal: d.canal, tipo: "paid", titulo: "Pagamento confirmado", texto: `${d.nome} quitou o débito de ${CJ_FMT(d.valor)}.` }); api.pushAtividade({ canal: d.canal, nome: d.nome, acao: "Pagamento confirmado", status: "paid" }); }
    },

    // ---- notificações
    pushNotif(n) { patch({ notifs: [{ id: uid("n"), lida: false, quando: "Agora", canal: "whatsapp", tipo: "sent", ...n }, ...state.notifs] }); },
    markNotifsRead() { patch({ notifs: state.notifs.map((n) => ({ ...n, lida: true })) }); },

    // ---- atividade
    pushAtividade(a) { patch({ atividade: [{ quando: "Agora", status: "sent", ...a }, ...state.atividade].slice(0, 8) }); },

    // ---- templates
    saveTemplate(id, p) { patch({ templates: state.templates.map((t) => (t.id === id ? { ...t, ...p } : t)) }); },
    addTemplate(t) {
      const novo = { id: uid("t"), nome: "Novo modelo", canal: "whatsapp", tom: "Cordial", assunto: "", corpo: "Prezado(a) {{nome}},\n\n", usos: 0, ativo: true, ...t };
      patch({ templates: [...state.templates, novo] });
      return novo;
    },
    duplicateTemplate(id) {
      const t = state.templates.find((x) => x.id === id);
      if (!t) return null;
      const novo = { ...t, id: uid("t"), nome: t.nome + " (cópia)", usos: 0 };
      patch({ templates: [...state.templates, novo] });
      return novo;
    },
    toggleTemplate(id) { patch({ templates: state.templates.map((t) => (t.id === id ? { ...t, ativo: !t.ativo } : t)) }); },
    removeTemplate(id) { patch({ templates: state.templates.filter((t) => t.id !== id) }); },

    // ---- agendamentos
    addAgendamento(a) {
      const novo = { id: uid("a"), status: "ativo", alvos: 0, proximo: "Amanhã, " + (a.hora || "09:00"), dias: [], ...a };
      patch({ agendamentos: [novo, ...state.agendamentos] });
      return novo;
    },
    toggleAgendamento(id) {
      patch({ agendamentos: state.agendamentos.map((s) => (s.id === id ? { ...s, status: s.status === "ativo" ? "pausado" : "ativo", proximo: s.status === "ativo" ? "Pausado" : "Amanhã, " + s.hora } : s)) });
    },
    removeAgendamento(id) { patch({ agendamentos: state.agendamentos.filter((s) => s.id !== id) }); },
  };
  return api;
})();

function useCJ() {
  const [, force] = React.useReducer((x) => x + 1, 0);
  React.useEffect(() => CJStore.subscribe(force), []);
  return CJStore.getState();
}

/* ---------- KPIs derivados ---------- */
const CJ_OPEN_STATUS = ["overdue", "pending", "sent", "scheduled"];
function cjKpis(devedores) {
  const aReceber = devedores.filter((d) => CJ_OPEN_STATUS.includes(d.status)).reduce((s, d) => s + d.valor, 0);
  const recuperado = devedores.filter((d) => d.status === "paid").reduce((s, d) => s + d.valor, 0);
  const emAtraso = devedores.filter((d) => d.status === "overdue").length;
  const enviados = devedores.filter((d) => d.status === "sent").length;
  return { aReceber, recuperado, emAtraso, enviados, total: devedores.length };
}

/* ---------- Parser de planilha (CSV nativo · XLSX via SheetJS) ---------- */
function cjParseValor(v) {
  if (typeof v === "number") return v;
  if (v == null) return 0;
  let s = String(v).replace(/[^\d.,-]/g, "");
  if (s.indexOf(",") > -1 && s.indexOf(".") > -1) s = s.replace(/\./g, "").replace(",", ".");
  else if (s.indexOf(",") > -1) s = s.replace(",", ".");
  return parseFloat(s) || 0;
}
function cjDiasAtraso(venc) {
  if (!venc) return 0;
  let dt = null;
  const s = String(venc).trim();
  const br = s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})$/);
  if (br) { let y = +br[3]; if (y < 100) y += 2000; dt = new Date(y, +br[2] - 1, +br[1]); }
  else { const d2 = new Date(s); if (!isNaN(d2)) dt = d2; }
  if (!dt || isNaN(dt)) return 0;
  const diff = Math.floor((Date.now() - dt.getTime()) / 86400000);
  return diff > 0 ? diff : 0;
}
const CJ_FIELD_MATCHERS = [
  { campo: "nome", re: /nome|razao|raz\u00e3o|cliente|devedor|sacado/ },
  { campo: "documento", re: /cpf|cnpj|documento|^doc/ },
  { campo: "telefone", re: /tel|fone|whats|celular|contato|cel/ },
  { campo: "email", re: /mail|e-mail/ },
  { campo: "fatura", re: /fatura|proc|contrato|titulo|t\u00edtulo|n\u00famero|numero/ },
  { campo: "valor", re: /valor|d\u00e9bito|debito|divida|d\u00edvida|montante|total|saldo/ },
  { campo: "vencimento", re: /venc|vencimento|data/ },
];
function cjNorm(s) { return (s || "").toString().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, ""); }
function cjGuessField(header) {
  const h = cjNorm(header);
  for (const m of CJ_FIELD_MATCHERS) if (m.re.test(h)) return m.campo;
  return "ignorar";
}
function cjParseCSV(text) {
  const lines = text.replace(/\r/g, "").split("\n").filter((l) => l.trim().length);
  if (!lines.length) return { headers: [], rows: [] };
  const delim = (lines[0].match(/;/g) || []).length > (lines[0].match(/,/g) || []).length ? ";" : ",";
  const split = (l) => l.split(delim).map((c) => c.trim().replace(/^"|"$/g, ""));
  const headers = split(lines[0]);
  const rows = lines.slice(1).map(split);
  return { headers, rows };
}
async function cjParseFile(file) {
  const name = (file.name || "").toLowerCase();
  if (name.endsWith(".csv") || file.type === "text/csv") {
    const text = await file.text();
    return cjParseCSV(text);
  }
  // XLSX/XLS — carrega SheetJS sob demanda
  if (!window.XLSX) {
    await new Promise((res, rej) => {
      const s = document.createElement("script");
      s.src = "https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js";
      s.onload = res; s.onerror = rej; document.head.appendChild(s);
    });
  }
  const buf = await file.arrayBuffer();
  const wb = window.XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const arr = window.XLSX.utils.sheet_to_json(ws, { header: 1, blankrows: false, defval: "" });
  if (!arr.length) return { headers: [], rows: [] };
  return { headers: arr[0].map(String), rows: arr.slice(1) };
}
function cjRowsToDevedores(headers, rows, mapping, canalPadrao) {
  // mapping: array same length as headers, each a campo key
  const idx = {};
  headers.forEach((h, i) => { const f = mapping[i]; if (f && f !== "ignorar" && idx[f] == null) idx[f] = i; });
  const out = [];
  let seq = 0;
  for (const r of rows) {
    const get = (f) => (idx[f] != null ? r[idx[f]] : "");
    const nome = String(get("nome") || "").trim();
    if (!nome) continue;
    seq++;
    const tel = String(get("telefone") || "").trim();
    const email = String(get("email") || "").trim();
    const proc = String(get("fatura") || "").trim() || ("IMP-" + Date.now().toString(36).slice(-4) + "-" + String(seq).padStart(3, "0"));
    const dias = cjDiasAtraso(get("vencimento"));
    let canal = canalPadrao || "whatsapp";
    if (canal === "auto") canal = tel ? "whatsapp" : email ? "email" : "sms";
    out.push({
      id: proc,
      nome,
      doc: String(get("documento") || "").trim() || "—",
      valor: cjParseValor(get("valor")),
      parcelas: "—",
      dias,
      status: dias > 30 ? "overdue" : dias > 0 ? "overdue" : "pending",
      canal,
      tel: tel || email || "—",
      ultimo: "Importado agora",
    });
  }
  return out;
}

Object.assign(window, {
  CJStore, useCJ, cjKpis, cjParseFile, cjRowsToDevedores, cjGuessField,
  cjParseValor, cjDiasAtraso, CJ_OPEN_STATUS, cjSeedConversa, cjResolveTemplate,
});

/* ---------- Conversas: seed determinístico + resolução de variáveis ---------- */
function cjFirstName(nome) { return (nome || "").replace(/\b(LTDA|ME|S\/A|EIRELI)\b/gi, "").trim().split(/\s+/)[0] || nome; }
function cjPrazoLimite(dias) {
  const d = new Date(); let add = dias || 5;
  while (add > 0) { d.setDate(d.getDate() + 1); const wd = d.getDay(); if (wd !== 0 && wd !== 6) add--; }
  return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" });
}
function cjPixCode(d) {
  // Pix "copia e cola" simulado (BR Code EMV-like), determinístico por devedor
  const valor = (d.valor || 0).toFixed(2);
  const txid = (d.id || "COBRAJURIS").replace(/[^A-Z0-9]/gi, "").slice(0, 12).toUpperCase();
  return `00020126360014BR.GOV.BCB.PIX0114auroracaminhoes000152040000530398654${String(valor.length).padStart(2,"0")}${valor}5802BR5920AURORA PECAS DIESEL6009SAO PAULO62${String(txid.length+4).padStart(2,"0")}05${String(txid.length).padStart(2,"0")}${txid}6304A1B2`;
}
function cjResolveTemplate(corpo, d) {
  const map = {
    "{{nome}}": d.nome,
    "{{fatura}}": d.id,
    "{{valor}}": CJ_FMT(d.valor),
    "{{valor_desconto}}": CJ_FMT(Math.round(d.valor * 0.6 * 100) / 100),
    "{{vencimento}}": "—",
    "{{dias}}": String(d.dias),
    "{{empresa}}": "Aurora Peças & Diesel",
    "{{cnpj}}": "12.345.678/0001-90",
    "{{prazo_limite}}": cjPrazoLimite(5),
    "{{link_acordo}}": "cobrajuris.app/acordo/" + (d.id || "").replace(/[^0-9]/g, "").slice(-5),
    "{{pix_copia_cola}}": cjPixCode(d),
  };
  return (corpo || "").replace(/\{\{\w+\}\}/g, (m) => (map[m] != null ? map[m] : m));
}
function cjSeedConversa(d) {
  const out = [];
  const nome = cjFirstName(d.nome);
  out.push({ id: "s1", dir: "out", canal: d.canal, status: "read", hora: "09:14",
    texto: `Olá ${nome}, identificamos uma pendência referente à fatura ${d.id} no valor de ${CJ_FMT(d.valor)}. Colocamo-nos à disposição para tratar da regularização.` });
  if (d.status === "paid") {
    out.push({ id: "s2", dir: "in", canal: d.canal, status: "read", hora: "10:02", texto: "Bom dia! Acabei de efetuar o pagamento, segue o comprovante em anexo." });
    out.push({ id: "s3", dir: "out", canal: d.canal, status: "read", hora: "10:05", texto: "Recebido, muito obrigado! O débito consta quitado. Permanecemos à disposição." });
  } else if (d.status === "sent") {
    out.push({ id: "s2", dir: "in", canal: d.canal, status: "read", hora: "11:20", texto: "Recebi a mensagem, vou verificar e retorno em breve." });
  } else if (d.status === "overdue" && d.dias > 30) {
    out.push({ id: "s2", dir: "out", canal: d.canal, status: "delivered", hora: "14:30",
      texto: `Reforçando nosso contato: o débito está vencido há ${d.dias} dias. Podemos avançar com uma proposta de acordo?` });
  }
  return out;
}
