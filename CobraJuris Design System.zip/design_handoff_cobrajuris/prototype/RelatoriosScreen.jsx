/* CobraJuris — Relatórios. Visão analítica: recuperação por mês,
   funil de cobrança, desempenho por canal e por régua/modelo.
   Combina dados reais do store com série histórica de demonstração. */

function RelatoriosScreen({ onNav }) {
  const DS = window.CobraJurisDesignSystem_4e03fb;
  const { StatCard, Badge } = DS;
  const { devedores, templates } = useCJ();
  const k = cjKpis(devedores);

  const [periodo, setPeriodo] = React.useState("6m");
  const MESES = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
  const [mesSel, setMesSel] = React.useState(5); // Junho

  // série histórica (demo) + mês atual derivado do store
  const HIST = [
    { mes: "Jan", recuperado: 128, meta: 160 },
    { mes: "Fev", recuperado: 142, meta: 160 },
    { mes: "Mar", recuperado: 175, meta: 180 },
    { mes: "Abr", recuperado: 169, meta: 180 },
    { mes: "Mai", recuperado: 198, meta: 200 },
    { mes: "Jun", recuperado: Math.round(k.recuperado / 1000) || 10, meta: 200 },
  ];
  const maxBar = Math.max(...HIST.map((h) => Math.max(h.recuperado, h.meta)));

  // funil
  const enviados = 13660;
  const funil = [
    { label: "Mensagens enviadas", value: enviados, pct: 100, tone: "var(--green-700)" },
    { label: "Entregues", value: Math.round(enviados * 0.94), pct: 94, tone: "var(--green-600)" },
    { label: "Lidas / abertas", value: Math.round(enviados * 0.61), pct: 61, tone: "var(--green-500)" },
    { label: "Responderam", value: Math.round(enviados * 0.38), pct: 38, tone: "var(--green-400)" },
    { label: "Acordo fechado", value: Math.round(enviados * 0.18), pct: 18, tone: "var(--brass-500)" },
  ];

  // desempenho por canal
  const canais = [
    { canal: "whatsapp", env: 9240, resp: 41, acordo: 21 },
    { canal: "email", env: 3180, resp: 28, acordo: 14 },
    { canal: "sms", env: 1240, resp: 19, acordo: 8 },
  ];

  // ranking de modelos por uso
  const ranking = [...templates].sort((a, b) => b.usos - a.usos).slice(0, 5);
  const maxUso = Math.max(1, ...ranking.map((t) => t.usos));

  return (
    <React.Fragment>
      {/* filtro de período */}
      <div className="cj-toolbar">
        <div className="cj-chiprow">
          {[["30d", "30 dias"], ["3m", "3 meses"], ["6m", "6 meses"], ["12m", "12 meses"]].map(([k2, lab]) => (
            <button key={k2} className={"cj-chip" + (periodo === k2 ? " cj-chip--active" : "")} onClick={() => setPeriodo(k2)}>{lab}</button>
          ))}
        </div>
        <div className="cj-toolbar__spacer"></div>
        <div className="cj-monthpick">
          <CJIcon name="calendar" size={16} />
          <select className="cj-select cj-monthpick__sel" value={mesSel} onChange={(e) => setMesSel(+e.target.value)}>
            {MESES.map((m, i) => <option key={m} value={i}>{m} de 2026</option>)}
          </select>
        </div>
        <button className="cj-btn cj-btn--secondary cj-btn--md" onClick={() => baixarRelatorioExcel(MESES[mesSel], 2026, devedores, k, canais, HIST, ranking)}><CJIcon name="sheet" size={16} />Baixar Excel</button>
      </div>

      {/* KPI ROW */}
      <div className="cj-grid cj-grid--4 cj-section">
        <StatCard label="Recuperado no período" value={CJ_FMT(987300)} delta="14,2%" deltaDirection="up" footnote="vs. período anterior" />
        <StatCard label="Taxa de acordo" value="18%" mono={false} delta="2,4%" deltaDirection="up" footnote="média do período" />
        <StatCard label="Tempo médio p/ acordo" value="6,4 dias" mono={false} delta="1,1 dia" deltaDirection="down" footnote="mais rápido" />
        <StatCard label="Custo por recuperação" value="R$ 2,18" mono={false} delta="0,3%" deltaDirection="down" footnote="por real recuperado" />
      </div>

      {/* recuperação por mês + funil */}
      <div className="cj-grid cj-grid--2 cj-section" style={{ alignItems: "start" }}>
        <div className="cj-card cj-card--pad">
          <div className="cj-section__head" style={{ marginBottom: "var(--space-5)" }}>
            <div className="cj-section__title">Recuperação por mês</div>
            <span className="cj-row cj-gap-3" style={{ fontSize: "var(--text-xs)" }}>
              <span className="cj-legend"><i style={{ background: "var(--green-500)" }}></i>Recuperado</span>
              <span className="cj-legend"><i style={{ background: "var(--border-strong)" }}></i>Meta</span>
            </span>
          </div>
          <div className="cj-barchart">
            {HIST.map((h) => (
              <div key={h.mes} className="cj-barcol">
                <div className="cj-barcol__bars">
                  <div className="cj-bar cj-bar--meta" style={{ height: (h.meta / maxBar * 100) + "%" }} title={"Meta: " + CJ_FMT(h.meta * 1000)}></div>
                  <div className="cj-bar cj-bar--val" style={{ height: (h.recuperado / maxBar * 100) + "%" }} title={"Recuperado: " + CJ_FMT(h.recuperado * 1000)}></div>
                </div>
                <span className="cj-barcol__label">{h.mes}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="cj-card cj-card--pad">
          <div className="cj-section__title" style={{ marginBottom: "var(--space-5)" }}>Funil de cobrança</div>
          <div className="cj-stack" style={{ gap: "var(--space-3)" }}>
            {funil.map((f) => (
              <div key={f.label} className="cj-funil">
                <div className="cj-funil__head">
                  <span className="cj-funil__label">{f.label}</span>
                  <span className="cj-funil__val tnum">{f.value.toLocaleString("pt-BR")} <span className="cj-muted">· {f.pct}%</span></span>
                </div>
                <div className="cj-funil__track"><div className="cj-funil__fill" style={{ width: f.pct + "%", background: f.tone }}></div></div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* canal + ranking modelos */}
      <div className="cj-grid cj-grid--2 cj-section" style={{ alignItems: "start" }}>
        <div className="cj-card" style={{ overflow: "hidden" }}>
          <div className="cj-section__head" style={{ padding: "var(--space-5) var(--space-5) var(--space-4)", marginBottom: 0 }}>
            <div className="cj-section__title">Desempenho por canal</div>
          </div>
          <table className="cj-table">
            <thead><tr><th>Canal</th><th>Enviados</th><th>Resposta</th><th>Acordo</th></tr></thead>
            <tbody>
              {canais.map((c) => {
                const cn = CJ_CANAL_LABEL[c.canal];
                return (
                  <tr key={c.canal}>
                    <td><span className={`cj-canal cj-canal--${c.canal}`}><CJIcon name={cn.icon} size={15} /> {cn.label}</span></td>
                    <td className="cj-td--num">{c.env.toLocaleString("pt-BR")}</td>
                    <td><span style={{ fontWeight: 700, color: "var(--success-600)" }}>{c.resp}%</span></td>
                    <td><span style={{ fontWeight: 700, color: "var(--text-strong)" }}>{c.acordo}%</span></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="cj-card cj-card--pad">
          <div className="cj-section__title" style={{ marginBottom: "var(--space-5)" }}>Modelos mais usados</div>
          <div className="cj-stack" style={{ gap: "var(--space-4)" }}>
            {ranking.map((t, i) => (
              <div key={t.id} className="cj-rank">
                <span className="cj-rank__pos">{i + 1}</span>
                <div className="cj-stack" style={{ flex: 1, minWidth: 0, gap: 5 }}>
                  <div className="cj-row" style={{ justifyContent: "space-between", gap: "var(--space-3)" }}>
                    <span className="cj-rank__name">{t.nome}</span>
                    <span className="cj-muted tnum" style={{ fontSize: "var(--text-xs)", whiteSpace: "nowrap" }}>{t.usos} envios</span>
                  </div>
                  <div className="cj-progress"><div className="cj-progress__fill" style={{ width: (t.usos / maxUso * 100) + "%" }}></div></div>
                </div>
              </div>
            ))}
            {ranking.every((t) => t.usos === 0) && <p className="cj-muted" style={{ fontSize: "var(--text-sm)" }}>Ainda sem envios suficientes para o ranking.</p>}
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}

window.RelatoriosScreen = RelatoriosScreen;

/* ----- Exportação de relatório mensal em Excel, branded CobraJuris -----
   Gera um .xls (HTML-table) que o Excel abre com as cores da marca:
   cabeçalho verde-petróleo, faixa da marca, zebra verde-claro. */
function baixarRelatorioExcel(mesNome, ano, devedores, k, canais, hist, ranking) {
  const G_DARK = "#0B4A36", G = "#0F6E4E", G_MID = "#1B8761", G_LIGHT = "#EAF5EF", G_LINE = "#CFE6DA", INK = "#0E1B17", MUTED = "#5E6B62";
  const fmt = (v) => "R$ " + (v || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const statusCount = (s) => devedores.filter((d) => d.status === s).length;
  const statusSoma = (s) => devedores.filter((d) => d.status === s).reduce((a, d) => a + d.valor, 0);

  const canalLabel = { whatsapp: "WhatsApp", email: "E-mail", sms: "SMS" };
  const statusRows = [
    ["Em atraso", statusCount("overdue"), statusSoma("overdue")],
    ["A vencer", statusCount("pending"), statusSoma("pending")],
    ["Enviados", statusCount("sent"), statusSoma("sent")],
    ["Agendados", statusCount("scheduled"), statusSoma("scheduled")],
    ["Quitados", statusCount("paid"), statusSoma("paid")],
  ];

  const cap = (lbl) => `<td style="background:${G};color:#fff;font-weight:700;padding:8px 12px;border:1px solid ${G_DARK};">${lbl}</td>`;
  const th = (lbl, align) => `<td style="background:${G_MID};color:#fff;font-weight:700;padding:7px 12px;border:1px solid ${G_LINE};text-align:${align||"left"};">${lbl}</td>`;
  const td = (v, i, align) => `<td style="background:${i % 2 ? "#fff" : G_LIGHT};color:${INK};padding:6px 12px;border:1px solid ${G_LINE};text-align:${align||"left"};">${v}</td>`;
  const spacer = `<tr><td colspan="4" style="height:10px;"></td></tr>`;

  let rows = "";
  // Marca / cabeçalho
  rows += `<tr><td colspan="4" style="background:${G_DARK};color:#fff;font-size:22px;font-weight:700;padding:16px 14px;border:1px solid ${G_DARK};">⚖ CobraJuris</td></tr>`;
  rows += `<tr><td colspan="4" style="background:${G};color:#fff;font-size:14px;padding:8px 14px;border:1px solid ${G_DARK};">Relatório Mensal de Cobrança — ${mesNome} de ${ano}</td></tr>`;
  rows += `<tr><td colspan="4" style="color:${MUTED};font-size:11px;padding:6px 14px;">Aurora Peças & Diesel Ltda · Gerado em ${new Date().toLocaleDateString("pt-BR")} · CobraJuris</td></tr>`;
  rows += spacer;

  // KPIs
  rows += `<tr>${cap("Indicadores do mês")}<td colspan="3" style="border:1px solid ${G_DARK};background:${G};"></td></tr>`;
  rows += `<tr>${th("Indicador")}${th("Valor", "right")}<td style="border:none;"></td><td style="border:none;"></td></tr>`;
  const kpis = [
    ["Total a receber (em aberto)", fmt(k.aReceber)],
    ["Recuperado / quitado", fmt(k.recuperado)],
    ["Faturas em atraso", String(k.emAtraso)],
    ["Total de devedores", String(k.total)],
    ["Taxa de quitação", (k.total ? Math.round(statusCount("paid") / k.total * 100) : 0) + "%"],
  ];
  kpis.forEach((r, i) => { rows += `<tr>${td(r[0], i)}${td(r[1], i, "right")}<td style="border:none;"></td><td style="border:none;"></td></tr>`; });
  rows += spacer;

  // Situação da carteira
  rows += `<tr>${cap("Situação da carteira")}<td colspan="3" style="border:1px solid ${G_DARK};background:${G};"></td></tr>`;
  rows += `<tr>${th("Situação")}${th("Qtde", "center")}${th("Valor", "right")}<td style="border:none;"></td></tr>`;
  statusRows.forEach((r, i) => { rows += `<tr>${td(r[0], i)}${td(r[1], i, "center")}${td(fmt(r[2]), i, "right")}<td style="border:none;"></td></tr>`; });
  rows += spacer;

  // Desempenho por canal
  rows += `<tr>${cap("Desempenho por canal")}<td colspan="3" style="border:1px solid ${G_DARK};background:${G};"></td></tr>`;
  rows += `<tr>${th("Canal")}${th("Enviados", "center")}${th("Resposta", "center")}${th("Acordo", "center")}</tr>`;
  canais.forEach((c, i) => { rows += `<tr>${td(canalLabel[c.canal] || c.canal, i)}${td(c.env.toLocaleString("pt-BR"), i, "center")}${td(c.resp + "%", i, "center")}${td(c.acordo + "%", i, "center")}</tr>`; });
  rows += spacer;

  // Recuperação por mês
  rows += `<tr>${cap("Recuperação por mês (R$ mil)")}<td colspan="3" style="border:1px solid ${G_DARK};background:${G};"></td></tr>`;
  rows += `<tr>${th("Mês")}${th("Recuperado", "right")}${th("Meta", "right")}<td style="border:none;"></td></tr>`;
  hist.forEach((h, i) => { rows += `<tr>${td(h.mes, i)}${td(fmt(h.recuperado * 1000), i, "right")}${td(fmt(h.meta * 1000), i, "right")}<td style="border:none;"></td></tr>`; });
  rows += spacer;

  // Devedores detalhados
  rows += `<tr>${cap("Devedores")}<td colspan="3" style="border:1px solid ${G_DARK};background:${G};"></td></tr>`;
  rows += `<tr>${th("Fatura")}${th("Nome")}${th("Valor", "right")}${th("Situação", "center")}</tr>`;
  const stLabel = { overdue: "Em atraso", pending: "A vencer", paid: "Quitado", scheduled: "Agendado", sent: "Enviado" };
  devedores.forEach((d, i) => { rows += `<tr>${td(d.id, i)}${td(d.nome, i)}${td(fmt(d.valor), i, "right")}${td(stLabel[d.status] || d.status, i, "center")}</tr>`; });

  const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>${mesNome} ${ano}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table style="font-family:Calibri,Arial,sans-serif;border-collapse:collapse;"><colgroup><col style="width:200px"><col style="width:200px"><col style="width:120px"><col style="width:120px"></colgroup>${rows}</table></body></html>`;

  const blob = new Blob(["\ufeff" + html], { type: "application/vnd.ms-excel;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `CobraJuris_Relatorio_${mesNome}_${ano}.xls`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1500);
}