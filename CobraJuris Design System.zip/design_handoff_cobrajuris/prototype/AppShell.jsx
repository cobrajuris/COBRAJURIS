/* CobraJuris — application shell: brand sidebar + topbar.
   Pure presentational chrome; `nav`/`onNav` drive the active item. */

const CJ_NAV = [
  { key: "dashboard",   label: "Painel",       icon: "dashboard" },
  { key: "devedores",   label: "Devedores",    icon: "users" },
  { key: "importar",    label: "Importar",     icon: "upload" },
  { key: "mensagens",   label: "Mensagens",    icon: "message" },
  { key: "agendamentos",label: "Agendamentos", icon: "calendar" },
  { key: "relatorios",  label: "Relatórios",   icon: "trendUp" },
];

function Wordmark({ compact = false, onClick }) {
  const Tag = onClick ? "button" : "div";
  return (
    <Tag className={"cj-wordmark" + (onClick ? " cj-wordmark--btn" : "")} onClick={onClick} {...(onClick ? { type: "button", title: "Ir para o início" } : {})}>
      {!compact && (
        <span className="cj-wordmark__text">
          Cobra<span className="cj-wordmark__accent">Juris</span>
        </span>
      )}
    </Tag>
  );
}

function Sidebar({ nav, onNav }) {
  const { devedores } = useCJ();
  const kpi = cjKpis(devedores);
  const meta = 80;
  const pct = Math.min(100, Math.round((kpi.enviados / meta) * 100));
  return (
    <aside className="cj-sidebar">
      <div className="cj-sidebar__brand">
        <Wordmark onClick={() => onNav("dashboard")} />
      </div>

      <div className="cj-sidebar__section-label">Operação</div>
      <nav className="cj-sidebar__nav">
        {CJ_NAV.map((item) => (
          <button
            key={item.key}
            className={"cj-navitem" + (nav === item.key ? " cj-navitem--active" : "")}
            onClick={() => onNav(item.key)}
          >
            <CJIcon name={item.icon} size={19} />
            <span>{item.label}</span>
            {item.key === "devedores" && <span className="cj-navitem__count">{devedores.length}</span>}
          </button>
        ))}
      </nav>

      <div className="cj-sidebar__card">
        <div className="cj-sidebar__card-row">
          <span className="cj-sidebar__card-label">Disparos hoje</span>
          <span className="cj-badge cj-badge--brand">{kpi.enviados} / {meta}</span>
        </div>
        <div className="cj-progress" style={{ marginTop: "10px" }}>
          <div className="cj-progress__fill" style={{ width: pct + "%" }}></div>
        </div>
        <p className="cj-sidebar__card-hint">Plano Empresa · renova em 8 dias</p>
      </div>

      <div className="cj-sidebar__foot">
        <button className={"cj-navitem" + (nav === "config" ? " cj-navitem--active" : "")} onClick={() => onNav("config")}>
          <CJIcon name="settings" size={19} />
          <span>Configurações</span>
        </button>
      </div>
    </aside>
  );
}

const CJ_NORM = (s) => (s || "").toString().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

function SearchBox({ onOpenDevedor }) {
  const { devedores } = useCJ();
  const [q, setQ] = React.useState("");
  const [open, setOpen] = React.useState(false);
  const [hi, setHi] = React.useState(0);
  const wrapRef = React.useRef(null);

  const results = q.trim().length >= 1
    ? devedores.filter((d) => {
        const t = CJ_NORM(q);
        return CJ_NORM(d.nome).includes(t) || CJ_NORM(d.doc).includes(t) || CJ_NORM(d.id).includes(t);
      }).slice(0, 6)
    : [];

  React.useEffect(() => { setHi(0); }, [q]);

  function choose(d) {
    onOpenDevedor(d);
    setQ("");
    setOpen(false);
  }
  function onKey(e) {
    if (!results.length) return;
    if (e.key === "ArrowDown") { e.preventDefault(); setHi((h) => Math.min(h + 1, results.length - 1)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setHi((h) => Math.max(h - 1, 0)); }
    else if (e.key === "Enter") { e.preventDefault(); choose(results[hi]); }
    else if (e.key === "Escape") { setOpen(false); }
  }

  const showDrop = open && q.trim().length >= 1;

  return (
    <div className="cj-topbar__search" ref={wrapRef}>
      <span className="cj-topbar__search-icon"><CJIcon name="search" size={18} /></span>
      <input
        placeholder="Buscar devedor, fatura ou CPF/CNPJ…"
        value={q}
        onChange={(e) => { setQ(e.target.value); setOpen(true); }}
        onFocus={() => setOpen(true)}
        onKeyDown={onKey}
      />
      {showDrop && (
        <React.Fragment>
          <div className="cj-overlay-catch" onMouseDown={() => setOpen(false)}></div>
          <div className="cj-search-drop">
            {results.length === 0 ? (
              <div className="cj-search-empty">Nenhum devedor encontrado para “{q}”.</div>
            ) : (
              <React.Fragment>
                <div className="cj-search-head">{results.length} resultado(s)</div>
                {results.map((d, i) => {
                  const st = CJ_STATUS_LABEL[d.status];
                  return (
                    <button
                      key={d.id}
                      className={"cj-search-item" + (i === hi ? " is-hi" : "")}
                      onMouseEnter={() => setHi(i)}
                      onMouseDown={(e) => { e.preventDefault(); choose(d); }}
                    >
                      <div className="cj-avatar cj-avatar--sm">{initials(d.nome)}</div>
                      <div className="cj-stack" style={{ minWidth: 0, flex: 1 }}>
                        <span className="cj-search-item__name">{d.nome}</span>
                        <span className="cj-search-item__meta">{d.id} · {d.doc}</span>
                      </div>
                      <span className="cj-stack" style={{ alignItems: "flex-end", gap: 4 }}>
                        <span className="tnum" style={{ fontWeight: 700, fontSize: "var(--text-sm)", color: "var(--text-strong)" }}>{CJ_FMT(d.valor)}</span>
                        <span className={`cj-badge cj-badge--${st.badge}`} style={{ fontSize: "10px", padding: "2px 7px" }}><span className="cj-badge__dot"></span>{st.label}</span>
                      </span>
                    </button>
                  );
                })}
              </React.Fragment>
            )}
          </div>
        </React.Fragment>
      )}
    </div>
  );
}

function NotificationsBell() {
  const { notifs } = useCJ();
  const [open, setOpen] = React.useState(false);
  const unread = notifs.filter((n) => !n.lida).length;
  const dot = { paid: "checkCircle", reply: "message", sent: "send", alert: "upload" };
  const tone = { paid: "var(--success-600)", reply: "var(--green-600)", sent: "var(--info-600)", alert: "var(--brass-600)" };

  return (
    <div className="cj-bell-wrap">
      <button className="cj-iconbtn cj-iconbtn--md cj-topbar__bell" title="Notificações" onClick={() => setOpen((o) => !o)}>
        <CJIcon name="bell" size={19} />
        {unread > 0 && <span className="cj-topbar__bell-dot"></span>}
      </button>
      {open && (
        <React.Fragment>
          <div className="cj-overlay-catch" onMouseDown={() => setOpen(false)}></div>
          <div className="cj-notif-drop">
            <div className="cj-notif-head">
              <span className="cj-notif-title">Notificações {unread > 0 && <span className="cj-notif-count">{unread}</span>}</span>
              <button className="cj-notif-markall" onClick={() => CJStore.markNotifsRead()} disabled={unread === 0}>Marcar lidas</button>
            </div>
            <div className="cj-notif-list">
              {notifs.length === 0 ? (
                <div className="cj-search-empty">Sem notificações.</div>
              ) : notifs.map((n) => (
                <div key={n.id} className={"cj-notif-item" + (n.lida ? "" : " is-unread")}>
                  <span className="cj-notif-icon" style={{ color: tone[n.tipo] }}><CJIcon name={dot[n.tipo] || "bell"} size={16} /></span>
                  <div className="cj-stack" style={{ flex: 1, minWidth: 0 }}>
                    <span className="cj-notif-item__title">{n.titulo}</span>
                    <span className="cj-notif-item__text">{n.texto}</span>
                    <span className="cj-notif-item__when">{n.quando}</span>
                  </div>
                  {!n.lida && <span className="cj-notif-unreaddot"></span>}
                </div>
              ))}
            </div>
          </div>
        </React.Fragment>
      )}
    </div>
  );
}

function Topbar({ title, subtitle, onLogout, actions, onOpenDevedor }) {
  const { session } = useCJ();
  const u = session.user || {};
  return (
    <header className="cj-topbar">
      <div className="cj-topbar__lead">
        <h1 className="cj-topbar__title">{title}</h1>
        {subtitle && <p className="cj-topbar__subtitle">{subtitle}</p>}
      </div>

      <SearchBox onOpenDevedor={onOpenDevedor} />

      <div className="cj-topbar__actions">
        {actions}
        <NotificationsBell />
        <div className="cj-topbar__user">
          <div className="cj-avatar cj-avatar--md" title={u.nome}>{u.iniciais || "HM"}</div>
          <div className="cj-topbar__user-meta">
            <span className="cj-topbar__user-name">Helena Martins</span>
            <span className="cj-topbar__user-role">{u.escritorio || "Aurora Peças"}</span>
          </div>
          <button className="cj-iconbtn cj-iconbtn--sm" onClick={onLogout} title="Sair">
            <CJIcon name="logout" size={17} />
          </button>
        </div>
      </div>
    </header>
  );
}

function AppShell({ nav, onNav, title, subtitle, actions, onLogout, onOpenDevedor, children }) {
  return (
    <div className="cj-app">
      <Sidebar nav={nav} onNav={onNav} />
      <div className="cj-app__main">
        <Topbar title={title} subtitle={subtitle} actions={actions} onLogout={onLogout} onOpenDevedor={onOpenDevedor} />
        <main className="cj-app__content">{children}</main>
      </div>
    </div>
  );
}

Object.assign(window, { AppShell, Sidebar, Topbar, Wordmark, SearchBox, NotificationsBell, CJ_NAV, CJ_NORM });
