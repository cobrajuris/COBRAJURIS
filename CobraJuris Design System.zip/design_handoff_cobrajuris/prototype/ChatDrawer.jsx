/* CobraJuris — Conversa do devedor. Aberta ao clicar no NOME.
   Mostra o histórico de mensagens (estilo WhatsApp / e-mail) e um
   compositor: digite ou use um modelo. Tudo que é disparado para o
   devedor (aqui, na lista, no painel ou em massa) aparece nesta thread. */

function ChatDrawer({ devedor, onClose, onOpenDetail, pushToast }) {
  const { conversas, templates } = useCJ();
  const d = devedor;
  const DS = window.CobraJurisDesignSystem_4e03fb;
  const { Badge } = DS;

  React.useEffect(() => { CJStore.ensureConversa(d); }, [d.id]);

  const msgs = conversas[d.id] || [];
  const [texto, setTexto] = React.useState("");
  const [showTpl, setShowTpl] = React.useState(false);
  const bodyRef = React.useRef(null);
  const cn = CJ_CANAL_LABEL[d.canal];
  const st = CJ_STATUS_LABEL[d.status];

  React.useEffect(() => {
    const el = bodyRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [msgs.length, d.id]);

  function enviar(t) {
    const txt = (t != null ? t : texto).trim();
    if (!txt) return;
    CJStore.sendMensagem(d.id, { texto: txt, canal: d.canal });
    CJStore.pushAtividade({ canal: d.canal, nome: d.nome, acao: "Mensagem enviada", status: "sent" });
    setTexto("");
    setShowTpl(false);
  }
  function usarModelo(tpl) {
    enviar(cjResolveTemplate(tpl.corpo, d));
    pushToast({ variant: "info", title: "Mensagem enviada", msg: `Modelo \u201c${tpl.nome}\u201d enviado a ${shortName(d.nome)}.` });
  }
  function simularResposta() {
    CJStore.receberMensagem(d.id, "Ol\u00e1, recebi a mensagem. Consigo regularizar at\u00e9 sexta-feira, pode ser?");
  }

  const ativos = templates.filter((t) => t.ativo);

  return (
    <React.Fragment>
      <div className="cj-drawer-overlay" onClick={onClose}></div>
      <aside className={"cj-drawer cj-chat cj-chat--" + d.canal} role="dialog" aria-label={`Conversa com ${d.nome}`}>
        {/* header */}
        <header className="cj-chat__head">
          <button className="cj-iconbtn cj-iconbtn--sm cj-chat__back" onClick={onClose} title="Fechar"><CJIcon name="chevronLeft" size={18} /></button>
          <div className="cj-avatar cj-avatar--md">{initials(d.nome)}</div>
          <div className="cj-stack" style={{ flex: 1, minWidth: 0 }}>
            <span className="cj-chat__name">{shortName(d.nome)}</span>
            <span className="cj-chat__status"><CJIcon name={cn.icon} size={13} /> {cn.label} · {d.tel}</span>
          </div>
          <button className="cj-iconbtn cj-iconbtn--sm" onClick={() => onOpenDetail(d)} title="Ver dados do devedor"><CJIcon name="user" size={17} /></button>
        </header>

        {/* débito strip */}
        <div className="cj-chat__debt">
          <div className="cj-row cj-gap-2">
            <span className="cj-chat__debt-label">Débito</span>
            <span className="cj-chat__debt-value tnum">{CJ_FMT(d.valor)}</span>
            <Badge variant={st.badge} dot>{st.label}</Badge>
          </div>
          <span className="cj-chat__debt-proc">{d.id}</span>
        </div>

        {/* messages */}
        <div className="cj-chat__body" ref={bodyRef}>
          <div className="cj-chat__day">Histórico de cobrança</div>
          {msgs.map((m) => (
            <div key={m.id} className={"cj-msg cj-msg--" + m.dir}>
              <div className="cj-msg__bubble">
                {m.texto}
                <span className="cj-msg__time">{m.hora}{m.dir === "out" && <span className="cj-msg__check">{m.status === "read" ? " ✓✓" : m.status === "delivered" ? " ✓✓" : " ✓"}</span>}</span>
              </div>
            </div>
          ))}
          {msgs.length === 0 && <div className="cj-chat__empty">Nenhuma mensagem ainda. Envie a primeira cobrança abaixo.</div>}
        </div>

        {/* template picker */}
        {showTpl && (
          <div className="cj-chat__tpls">
            <div className="cj-chat__tpls-head">
              <span>Enviar com um modelo</span>
              <button className="cj-iconbtn cj-iconbtn--sm" onClick={() => setShowTpl(false)}><CJIcon name="x" size={15} /></button>
            </div>
            <div className="cj-chat__tpls-list">
              {ativos.map((t) => (
                <button key={t.id} className="cj-chat__tpl" onClick={() => usarModelo(t)}>
                  <span className="cj-chat__tpl-name">{t.nome}</span>
                  <span className="cj-chat__tpl-prev">{cjResolveTemplate(t.corpo, d).slice(0, 64)}…</span>
                </button>
              ))}
              {ativos.length === 0 && <div className="cj-chat__empty" style={{ padding: 12 }}>Nenhum modelo ativo.</div>}
            </div>
          </div>
        )}

        {/* composer */}
        <footer className="cj-chat__composer">
          <button className="cj-iconbtn cj-iconbtn--md" title="Usar modelo" onClick={() => setShowTpl((s) => !s)}><CJIcon name="fileText" size={18} /></button>
          <textarea
            className="cj-chat__input"
            placeholder={`Mensagem para ${shortName(d.nome)}…`}
            value={texto}
            onChange={(e) => setTexto(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); enviar(); } }}
            rows={1}
          />
          <button className="cj-chat__send" onClick={() => enviar()} disabled={!texto.trim()} title="Enviar"><CJIcon name="send" size={18} /></button>
        </footer>
        <button className="cj-chat__simular" onClick={simularResposta}>↩ Simular resposta do devedor (demo)</button>
      </aside>
    </React.Fragment>
  );
}

window.ChatDrawer = ChatDrawer;
