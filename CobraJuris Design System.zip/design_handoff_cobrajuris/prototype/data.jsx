/* CobraJuris — dados de exemplo das telas do UI kit.
   Cenário real: distribuidora de peças de caminhão cobrando seus
   clientes (oficinas, transportadoras, frotistas, autônomos). */

const CJ_DEVEDORES = [
  { id: "FAT-2024-0182", nome: "Auto Diesel Center ME", doc: "18.244.390/0001-22", valor: 4820.50, parcelas: "3/12", dias: 47, status: "overdue", canal: "whatsapp", tel: "(11) 98823-4471", ultimo: "Há 2 dias" },
  { id: "FAT-2024-0177", nome: "Transportadora Rota Norte LTDA", doc: "12.884.560/0001-09", valor: 28740.00, parcelas: "1/6", dias: 12, status: "pending", canal: "email", tel: "financeiro@rotanorte.com.br", ultimo: "Hoje" },
  { id: "FAT-2024-0165", nome: "Oficina do Zé Caminhões", doc: "44.522.011/0001-70", valor: 1290.00, parcelas: "—", dias: 0, status: "paid", canal: "whatsapp", tel: "(21) 99710-2284", ultimo: "Há 5 dias" },
  { id: "FAT-2024-0158", nome: "Frota Expressa Logística LTDA", doc: "33.090.155/0001-11", valor: 9650.75, parcelas: "5/10", dias: 89, status: "overdue", canal: "sms", tel: "(31) 98114-7763", ultimo: "Há 1 dia" },
  { id: "FAT-2024-0151", nome: "Mecânica Truck Master ME", doc: "22.866.743/0001-05", valor: 3400.00, parcelas: "2/8", dias: 4, status: "pending", canal: "whatsapp", tel: "(11) 97456-1180", ultimo: "Há 6 horas" },
  { id: "FAT-2024-0149", nome: "Distribuidora Rodovale Peças LTDA", doc: "08.112.339/0001-44", valor: 15280.00, parcelas: "—", dias: 23, status: "scheduled", canal: "email", tel: "contato@rodovale.com", ultimo: "Agendado" },
  { id: "FAT-2024-0142", nome: "José Carlos Motorista Autônomo", doc: "511.003.872-90", valor: 720.00, parcelas: "1/3", dias: 61, status: "overdue", canal: "whatsapp", tel: "(85) 98330-5521", ultimo: "Há 3 dias" },
  { id: "FAT-2024-0138", nome: "Retífica Motor Forte LTDA", doc: "39.044.821/0001-63", valor: 5125.40, parcelas: "4/12", dias: 7, status: "sent", canal: "whatsapp", tel: "(41) 99002-8847", ultimo: "Há 1 hora" },
  { id: "FAT-2024-0131", nome: "Transportes Horizonte LTDA", doc: "20.554.871/0001-12", valor: 42900.00, parcelas: "2/4", dias: 34, status: "overdue", canal: "email", tel: "financeiro@horizonte.log", ultimo: "Há 4 dias" },
  { id: "FAT-2024-0127", nome: "Borracharia Pneus Pesados Silva", doc: "60.122.974/0001-38", valor: 2180.00, parcelas: "—", dias: 2, status: "pending", canal: "sms", tel: "(51) 98445-9923", ultimo: "Ontem" },
  { id: "FAT-2024-0119", nome: "Cooperativa de Transportes União", doc: "17.288.033/0001-50", valor: 8760.00, parcelas: "6/6", dias: 0, status: "paid", canal: "whatsapp", tel: "(62) 99115-7720", ultimo: "Há 8 dias" },
  { id: "FAT-2024-0114", nome: "Auto Peças Estrada Real ME", doc: "33.901.226/0001-78", valor: 1940.30, parcelas: "1/2", dias: 18, status: "sent", canal: "whatsapp", tel: "(11) 97781-3360", ultimo: "Há 2 horas" },
];

const CJ_STATUS_LABEL = {
  overdue:   { label: "Em atraso",  badge: "danger" },
  pending:   { label: "A vencer",   badge: "warning" },
  paid:      { label: "Quitado",    badge: "success" },
  scheduled: { label: "Agendado",   badge: "neutral" },
  sent:      { label: "Enviado",    badge: "info" },
};

const CJ_CANAL_LABEL = {
  whatsapp: { label: "WhatsApp", icon: "whatsapp" },
  sms:      { label: "SMS",      icon: "smartphone" },
  email:    { label: "E-mail",   icon: "mail" },
};

const CJ_TEMPLATES = [
  {
    id: "t1", nome: "Lembrete amigável — 1º contato", canal: "whatsapp", tom: "Cordial",
    assunto: "Lembrete de pendência financeira",
    corpo: "Olá, {{nome}}! Tudo bem?\n\nIdentificamos em nossos registros uma pendência referente à fatura {{fatura}}, no valor de {{valor}}, com vencimento em {{vencimento}}.\n\nColocamo-nos à disposição para regularizar da melhor forma. Qualquer dúvida, é só responder esta mensagem.\n\nAtenciosamente,\nEquipe Financeira — {{empresa}}",
    usos: 184, ativo: true,
  },
  {
    id: "t2", nome: "Cobrança formal — atraso 30+ dias", canal: "email", tom: "Formal",
    assunto: "Débito em aberto — Fatura {{fatura}}",
    corpo: "Prezado(a) {{nome}},\n\nConsta em aberto a fatura {{fatura}}, no valor atualizado de {{valor}}, vencida há {{dias}} dias.\n\nSolicitamos a regularização no prazo de 5 (cinco) dias úteis. Não havendo retorno, o débito poderá ser encaminhado para negativação nos órgãos de proteção ao crédito (SPC/Serasa) e demais medidas de cobrança cabíveis.\n\nPara quitar agora: {{link_acordo}}\n\nAtenciosamente,\n{{empresa}} — CNPJ {{cnpj}}",
    usos: 97, ativo: true,
  },
  {
    id: "t3", nome: "Proposta de acordo — parcelamento", canal: "whatsapp", tom: "Cordial",
    assunto: "Proposta de regularização",
    corpo: "Olá, {{nome}}!\n\nReferente à fatura {{fatura}} ({{valor}}), temos uma condição especial de parcelamento para você regularizar com tranquilidade.\n\nResponda esta mensagem para conhecer as opções disponíveis.\n\nAtenciosamente,\n{{empresa}}",
    usos: 56, ativo: true,
  },
  {
    id: "t4", nome: "Confirmação de quitação", canal: "email", tom: "Cordial",
    assunto: "Confirmação de pagamento — Fatura {{fatura}}",
    corpo: "Olá, {{nome}}!\n\nConfirmamos o recebimento do pagamento referente à fatura {{fatura}}. O débito encontra-se devidamente quitado.\n\nAgradecemos pela parceria e permanecemos à disposição.\n\nAtenciosamente,\n{{empresa}}",
    usos: 41, ativo: false,
  },
  {
    id: "t5", nome: "Notificação de negativação", canal: "email", tom: "Formal",
    assunto: "Aviso de negativação — Fatura {{fatura}}",
    corpo: "Prezado(a) {{nome}},\n\nApesar de nossos contatos anteriores, permanece em aberto a fatura {{fatura}}, no valor atualizado de {{valor}}, vencida há {{dias}} dias.\n\nInformamos que, não havendo regularização até {{prazo_limite}}, o débito será encaminhado para inclusão nos órgãos de proteção ao crédito (SPC/Serasa) e, conforme o caso, a protesto em cartório.\n\nEvite essa etapa regularizando agora: {{link_acordo}}\n\nAtenciosamente,\n{{empresa}} — CNPJ {{cnpj}}",
    usos: 0, ativo: true,
  },
  {
    id: "t6", nome: "Mutirão de Acordos — desconto", canal: "whatsapp", tom: "Conciliador",
    assunto: "Mutirão de Acordos — condição especial",
    corpo: "Olá, {{nome}}! Tudo bem? 🤝\n\nEstamos com um Mutirão de Acordos por tempo limitado e a sua fatura {{fatura}} entrou na lista de condições especiais.\n\n💚 À vista: de {{valor}} por apenas {{valor_desconto}}\n💳 Ou parcelado, do seu jeito.\n\nÉ a chance de zerar essa pendência e ficar tranquilo(a). A condição vale até {{prazo_limite}}.\n\nRegularize agora 👉 {{link_acordo}}\nPix copia e cola: {{pix_copia_cola}}\n\n{{empresa}}",
    usos: 0, ativo: true,
  },
  {
    id: "t7", nome: "Aviso de pré-vencimento", canal: "whatsapp", tom: "Cordial",
    assunto: "Sua fatura vence em breve",
    corpo: "Olá, {{nome}}! 😊\n\nPassando para lembrar que a sua fatura {{fatura}}, no valor de {{valor}}, vence em {{vencimento}}.\n\nPara evitar juros, você já pode pagar pelo Pix:\n{{pix_copia_cola}}\n\nQualquer dúvida, é só responder. Obrigado pela preferência!\n{{empresa}}",
    usos: 0, ativo: true,
  },
  {
    id: "t8", nome: "2ª via de boleto / fatura", canal: "whatsapp", tom: "Cordial",
    assunto: "Segunda via da sua fatura",
    corpo: "Olá, {{nome}}!\n\nSegue a 2ª via da fatura {{fatura}}, no valor de {{valor}}, para regularização:\n\n🔗 {{link_acordo}}\nPix copia e cola: {{pix_copia_cola}}\n\nAssim que o pagamento for identificado, confirmamos por aqui. Obrigado!\n{{empresa}}",
    usos: 0, ativo: true,
  },
];

const CJ_AGENDAMENTOS = [
  { id: "a1", nome: "Régua — faturas vencidas há 30+ dias", template: "Cobrança formal — atraso 30+ dias", canal: "email", hora: "09:00", dias: ["Seg", "Qua", "Sex"], alvos: 34, status: "ativo", proximo: "Amanhã, 09:00" },
  { id: "a2", nome: "Lembrete de pré-vencimento", template: "Aviso de pré-vencimento", canal: "whatsapp", hora: "10:30", dias: ["Ter", "Qui"], alvos: 18, status: "ativo", proximo: "Hoje, 10:30" },
  { id: "a3", nome: "Mutirão de acordos — quinzenal", template: "Mutirão de Acordos — desconto", canal: "whatsapp", hora: "14:00", dias: ["Seg"], alvos: 9, status: "pausado", proximo: "Pausado" },
];

const CJ_ATIVIDADE = [
  { canal: "whatsapp", nome: "Retífica Motor Forte LTDA", acao: "Mensagem entregue", quando: "Há 12 min", status: "sent" },
  { canal: "whatsapp", nome: "Auto Peças Estrada Real ME", acao: "Mensagem lida", quando: "Há 38 min", status: "sent" },
  { canal: "email", nome: "Transportadora Rota Norte LTDA", acao: "E-mail aberto", quando: "Há 1 h", status: "sent" },
  { canal: "whatsapp", nome: "Oficina do Zé Caminhões", acao: "Pagamento confirmado", quando: "Há 2 h", status: "paid" },
  { canal: "sms", nome: "Borracharia Pneus Pesados Silva", acao: "SMS entregue", quando: "Há 3 h", status: "sent" },
];

const CJ_FMT = (v) => v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

const CJ_NOTIFS = [
  { id: "n1", canal: "whatsapp", tipo: "paid",  titulo: "Pagamento confirmado", texto: "Oficina do Zé Caminhões quitou o débito de R$ 1.290,00.", quando: "Há 12 min", lida: false },
  { id: "n2", canal: "whatsapp", tipo: "reply", titulo: "Resposta recebida", texto: "Auto Diesel Center respondeu à cobrança e pediu acordo.", quando: "Há 38 min", lida: false },
  { id: "n3", canal: "email",    tipo: "sent",  titulo: "E-mail aberto", texto: "Transportadora Rota Norte abriu a cobrança de fatura.", quando: "Há 1 h", lida: false },
  { id: "n4", canal: "sms",      tipo: "sent",  titulo: "Régua executada", texto: "18 disparos enviados pela régua 'Pré-vencimento'.", quando: "Há 2 h", lida: true },
  { id: "n5", canal: "email",    tipo: "alert", titulo: "Importação concluída", texto: "342 clientes adicionados à base de cobrança.", quando: "Ontem", lida: true },
];

Object.assign(window, {
  CJ_DEVEDORES, CJ_STATUS_LABEL, CJ_CANAL_LABEL, CJ_TEMPLATES,
  CJ_AGENDAMENTOS, CJ_ATIVIDADE, CJ_FMT, CJ_NOTIFS,
});
