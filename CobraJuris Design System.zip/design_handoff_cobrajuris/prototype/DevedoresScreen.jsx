/* CobraJuris — Devedores. Filterable table with multi-select,
   bulk dispatch action, status chips, pagination. */

function DevedoresScreen({ onNav, pushToast, onOpenDevedor, onOpenChat }) {
  const DS = window.CobraJurisDesignSystem_4e03fb;
  const { Badge, Button } = DS;
  const { devedores } = useCJ();

  const FILTERS = [
    { key: "todos", label: "Todos" },
    { key: "overdue", label: "Em atraso" },
    { key: "pending", label: "A vencer" },
    { key: "sent", label: "Enviados" },
    { key: "scheduled", label: "Agendados" },
    { key: "paid", label: "Quitados" },
  ];
  const [filter, setFilter] = React.useState("todos");
  const [selected, setSelected] = React.useState(() => new Set());
  const [novo, setNovo] = React.useState(false);
  const [confirmLimpar, setConfirmLimpar] = React.useState(false);
  const [confirmTodos, setConfirmTodos] = React.useState(false);

  const emAberto = devedores.filter((d) => CJ_OPEN_STATUS.includes(d.status));
  function dispararTodos() {
    const ids = emAberto.map((d) => d.id);
    CJStore.dispatch(ids);
    CJStore.pushNotif({ tipo: "sent", titulo: "Disparo para todos", texto: `${ids.length} cliente(s) em aberto receberam a cobrança.` });
    pushToast({ variant: "success", title: `Cobrança enviada para ${ids.length} cliente(s)`, msg: "Todos os clientes com fatura em aberto entraram na fila de disparo." });
    setConfirmTodos(false);
  }

  const rows = devedores.filter((d) => filter === "todos" || d.status === filter);
  const allOn = rows.length > 0 && rows.every((d) => selected.has(d.id));

  function toggle(id) {
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }
  function toggleAll() {
    setSelected((prev) => {
      if (rows.every((d) => prev.has(d.id))) return new Set();
      return new Set(rows.map((d) => d.id));
    });
  }
  function dispatch() {
    const ids = [...selected];
    CJStore.dispatch(ids);
    CJStore.pushNotif({ tipo: "sent", titulo: "Disparo em massa", texto: `${ids.length} cobrança(s) enfileirada(s) para envio.` });
    pushToast({ variant: "success", title: `${ids.length} cobrança(s) enfileirada(s)`, msg: "Os disparos serão enviados conforme a régua ativa." });
    setSelected(new Set());
  }
  function enviarUm(d) {
    CJStore.dispatch([d.id]);
    CJStore.pushAtividade({ canal: d.canal, nome: d.nome, acao: "Cobrança enviada", status: "sent" });
    pushToast({ variant: "info", title: "Cobrança enviada", msg: `Mensagem enviada a ${shortName(d.nome)}.` });
  }
  function excluir(d) {
    CJStore.removeDevedor(d.id);
    setSelected((prev) => { const n = new Set(prev); n.delete(d.id); return n; });
    pushToast({ variant: "danger", title: "Devedor removido", msg: `${shortName(d.nome)} foi excluído da base.` });
  }
  function limparSelecionados() {
    const ids = [...selected];
    ids.forEach((id) => CJStore.removeDevedor(id));
    CJStore.pushNotif({ tipo: "alert", titulo: "Devedores removidos", texto: `${ids.length} devedor(es) foram excluídos da base de cobrança.` });
    pushToast({ variant: "danger", title: `${ids.length} devedor(es) excluído(s)`, msg: "Os registros foram removidos da base." });
    setSelected(new Set());
    setConfirmLimpar(false);
  }

  const count = (k) => (k === "todos" ? devedores.length : devedores.filter((d) => d.status === k).length);

  return (
    <React.Fragment>
      {/* Toolbar */}
      <div className="cj-toolbar">
        <div className="cj-chiprow">
          {FILTERS.map((f) => (
            <button key={f.key} className={"cj-chip" + (filter === f.key ? " cj-chip--active" : "")} onClick={() => setFilter(f.key)}>
              {f.label} <span className="cj-chip__count">{count(f.key)}</span>
            </button>
          ))}
        </div>
        <div className="cj-toolbar__spacer"></div>
        <Button variant="secondary" size="md" leftIcon={<CJIcon name="download" size={16} />} onClick={() => exportarCSV(rows)}>Exportar</Button>
        <Button variant="secondary" size="md" leftIcon={<CJIcon name="plus" size={16} />} onClick={() => setNovo(true)}>Novo devedor</Button>
        <Button size="md" leftIcon={<CJIcon name="send" size={16} />} onClick={() => setConfirmTodos(true)} disabled={emAberto.length === 0}>Disparar para todos</Button>
      </div>

      {/* Bulk bar */}
      {selected.size > 0 && (
        <div className="cj-card" style={{ display: "flex", alignItems: "center", gap: "var(--space-4)", padding: "var(--space-3) var(--space-5)", marginBottom: "var(--space-4)", background: "var(--green-50)", borderColor: "var(--green-200)" }}>
          <span style={{ fontWeight: 700, color: "var(--green-800)", fontSize: "var(--text-sm)" }}>{selected.size} selecionado(s)</span>
          <div className="cj-toolbar__spacer"></div>
          <Button variant="ghost" size="sm" onClick={() => setSelected(new Set())}>Desmarcar</Button>
          <Button variant="secondary" size="sm" leftIcon={<CJIcon name="calendar" size={15} />} onClick={() => onNav("agendamentos")}>Agendar</Button>
          <Button variant="secondary" size="sm" leftIcon={<CJIcon name="send" size={15} />} onClick={dispatch}>Disparar agora</Button>
          <Button variant="danger" size="sm" leftIcon={<CJIcon name="trash" size={15} />} onClick={() => setConfirmLimpar(true)}>Limpar</Button>
        </div>
      )}

      {/* Table */}
      <div className="cj-table-wrap">
        <table className="cj-table">
          <thead>
            <tr>
              <th style={{ width: 40 }}>
                <span className="cj-checkcell"><input type="checkbox" checked={allOn} onChange={toggleAll} /></span>
              </th>
              <th>Devedor</th>
              <th>Fatura</th>
              <th>Valor</th>
              <th>Parcela</th>
              <th>Atraso</th>
              <th>Canal</th>
              <th>Situação</th>
              <th style={{ width: 90 }}></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((d) => {
              const st = CJ_STATUS_LABEL[d.status];
              const cn = CJ_CANAL_LABEL[d.canal];
              const on = selected.has(d.id);
              return (
                <tr key={d.id} style={on ? { background: "var(--green-50)" } : null}>
                  <td><span className="cj-checkcell"><input type="checkbox" checked={on} onChange={() => toggle(d.id)} /></span></td>
                  <td>
                    <div className="cj-namecell">
                      <div className="cj-avatar cj-avatar--sm">{initials(d.nome)}</div>
                      <div className="cj-stack">
                        <button className="cj-namecell__name cj-namecell__link" style={{ fontSize: "var(--text-sm)" }} onClick={() => onOpenChat && onOpenChat(d)} title="Abrir conversa">{d.nome}</button>
                        <span className="cj-namecell__meta">{d.doc}</span>
                      </div>
                    </div>
                  </td>
                  <td><span className="cj-namecell__meta" style={{ fontSize: "var(--text-xs)" }}>{d.id}</span></td>
                  <td className="cj-td--num">{CJ_FMT(d.valor)}</td>
                  <td className="cj-muted">{d.parcelas}</td>
                  <td>{d.dias > 0 ? <span style={{ color: d.dias > 30 ? "var(--danger-600)" : "var(--text-secondary)", fontWeight: d.dias > 30 ? 700 : 400 }}>{d.dias}d</span> : <span className="cj-muted">—</span>}</td>
                  <td><span className={`cj-canal cj-canal--${d.canal}`}><CJIcon name={cn.icon} size={15} /> {cn.label}</span></td>
                  <td><Badge variant={st.badge} dot>{st.label}</Badge></td>
                  <td>
                    <div className="cj-rowactions">
                      <button className="cj-iconbtn cj-iconbtn--sm" title="Abrir conversa" onClick={() => onOpenChat && onOpenChat(d)}><CJIcon name="message" size={16} /></button>
                      <button className="cj-iconbtn cj-iconbtn--sm" title="Ver dados" onClick={() => onOpenDevedor && onOpenDevedor(d)}><CJIcon name="eye" size={16} /></button>
                      <button className="cj-iconbtn cj-iconbtn--sm" title="Excluir" onClick={() => excluir(d)}><CJIcon name="trash" size={16} /></button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="cj-pagination">
        <span className="cj-pagination__info">Mostrando {rows.length} de {devedores.length} faturas</span>
        <div className="cj-pagination__pages">
          <button className="cj-pagebtn"><CJIcon name="chevronLeft" size={16} /></button>
          <button className="cj-pagebtn cj-pagebtn--active">1</button>
          <button className="cj-pagebtn">2</button>
          <button className="cj-pagebtn">3</button>
          <button className="cj-pagebtn"><CJIcon name="chevronRight" size={16} /></button>
        </div>
      </div>

      {novo && <NovoDevedorModal onClose={() => setNovo(false)} pushToast={pushToast} />}
      {confirmTodos && (
        <ConfirmModal
          tone="primary"
          icon="send"
          title={`Disparar cobrança para ${emAberto.length} cliente(s)?`}
          message={`A mensagem será enviada para todos os clientes com fatura em aberto (em atraso, a vencer, enviados e agendados), pelo canal de cada um. Clientes já quitados não recebem.`}
          confirmLabel={`Disparar para ${emAberto.length}`}
          cancelLabel="Cancelar"
          onConfirm={dispararTodos}
          onClose={() => setConfirmTodos(false)}
        />
      )}
      {confirmLimpar && (
        <ConfirmModal
          tone="danger"
          icon="trash"
          title={`Limpar ${selected.size} devedor(es)?`}
          message={`Esta ação vai apagar ${selected.size} devedor(es) selecionado(s) e todo o histórico de conversa deles. Esta ação não pode ser desfeita.`}
          confirmLabel={`Sim, apagar ${selected.size}`}
          cancelLabel="Cancelar"
          onConfirm={limparSelecionados}
          onClose={() => setConfirmLimpar(false)}
        />
      )}
    </React.Fragment>
  );
}

function ConfirmModal({ tone = "danger", icon = "alert", title, message, confirmLabel, cancelLabel = "Cancelar", onConfirm, onClose }) {
  const DS = window.CobraJurisDesignSystem_4e03fb;
  const { Button } = DS;
  React.useEffect(() => {
    const h = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, []);
  return (
    <React.Fragment>
      <div className="cj-drawer-overlay" onClick={onClose}></div>
      <div className="cj-modal cj-modal--sm" role="alertdialog" aria-label={title}>
        <div className="cj-confirm">
          <span className={"cj-confirm__icon cj-confirm__icon--" + tone}><CJIcon name={icon} size={26} /></span>
          <h2 className="cj-confirm__title">{title}</h2>
          <p className="cj-confirm__msg">{message}</p>
          <div className="cj-confirm__actions">
            <Button variant="secondary" onClick={onClose}>{cancelLabel}</Button>
            <Button variant={tone === "danger" ? "danger" : "primary"} onClick={onConfirm} leftIcon={<CJIcon name={icon} size={16} />}>{confirmLabel}</Button>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}

function exportarCSV(rows) {
  const head = ["Fatura", "Nome", "Documento", "Valor", "Parcela", "Atraso", "Canal", "Situacao"];
  const body = rows.map((d) => [d.id, d.nome, d.doc, d.valor, d.parcelas, d.dias, d.canal, d.status].join(";"));
  const csv = [head.join(";"), ...body].join("\n");
  const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "cobrajuris_devedores.csv";
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

function NovoDevedorModal({ onClose, pushToast }) {
  const DS = window.CobraJurisDesignSystem_4e03fb;
  const { Button } = DS;
  const [f, setF] = React.useState({ nome: "", doc: "", tel: "", valor: "", canal: "whatsapp" });
  const set = (k) => (e) => setF((p) => ({ ...p, [k]: e.target.value }));
  const valido = f.nome.trim() && f.valor;

  function salvar() {
    const d = CJStore.addDevedor({ nome: f.nome.trim(), doc: f.doc.trim() || "—", tel: f.tel.trim() || "—", valor: cjParseValor(f.valor), canal: f.canal });
    CJStore.pushNotif({ tipo: "alert", canal: f.canal, titulo: "Devedor adicionado", texto: `${d.nome} entrou na base de cobrança.` });
    pushToast({ variant: "success", title: "Devedor adicionado", msg: `${shortName(d.nome)} foi incluído na base.` });
    onClose();
  }

  return (
    <React.Fragment>
      <div className="cj-drawer-overlay" onClick={onClose}></div>
      <div className="cj-modal" role="dialog" aria-label="Novo devedor">
        <div className="cj-modal__head">
          <span className="cj-section__title">Novo devedor</span>
          <button className="cj-iconbtn cj-iconbtn--sm" onClick={onClose} title="Fechar"><CJIcon name="x" size={18} /></button>
        </div>
        <div className="cj-modal__body">
          <div className="cj-field">
            <label className="cj-label">Nome / Razão social</label>
            <input className="cj-input" value={f.nome} onChange={set("nome")} placeholder="Ex.: João da Silva" autoFocus />
          </div>
          <div className="cj-row cj-gap-3">
            <div className="cj-field" style={{ flex: 1 }}>
              <label className="cj-label">CPF / CNPJ</label>
              <input className="cj-input" value={f.doc} onChange={set("doc")} placeholder="000.000.000-00" />
            </div>
            <div className="cj-field" style={{ flex: 1 }}>
              <label className="cj-label">Valor do débito</label>
              <input className="cj-input" value={f.valor} onChange={set("valor")} placeholder="R$ 0,00" />
            </div>
          </div>
          <div className="cj-field">
            <label className="cj-label">Contato (telefone ou e-mail)</label>
            <input className="cj-input" value={f.tel} onChange={set("tel")} placeholder="(11) 90000-0000" />
          </div>
          <div className="cj-field">
            <label className="cj-label">Canal de cobrança</label>
            <div className="cj-row cj-gap-2">
              {Object.entries(CJ_CANAL_LABEL).map(([k, v]) => (
                <button key={k} className={"cj-chip" + (f.canal === k ? " cj-chip--active" : "")} onClick={() => setF((p) => ({ ...p, canal: k }))} style={{ flex: 1, justifyContent: "center" }}>
                  <CJIcon name={v.icon} size={15} /> {v.label}
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="cj-modal__foot">
          <Button variant="secondary" onClick={onClose}>Cancelar</Button>
          <Button onClick={salvar} disabled={!valido} leftIcon={<CJIcon name="check" size={16} />}>Adicionar devedor</Button>
        </div>
      </div>
    </React.Fragment>
  );
}

window.DevedoresScreen = DevedoresScreen;
