/* CobraJuris — Mensagens. Template library + live editor with
   variable insertion and channel-accurate preview (WhatsApp / e-mail). */

function MensagensScreen({ pushToast }) {
  const DS = window.CobraJurisDesignSystem_4e03fb;
  const { Button, Badge, Input } = DS;
  const { templates } = useCJ();

  const [activeId, setActiveId] = React.useState(templates[0] && templates[0].id);
  const active = templates.find((t) => t.id === activeId) || templates[0];
  const [corpo, setCorpo] = React.useState(active ? active.corpo : "");
  const [assunto, setAssunto] = React.useState(active ? active.assunto : "");
  const [dirty, setDirty] = React.useState(false);
  const taRef = React.useRef(null);

  React.useEffect(() => {
    if (!active) return;
    setCorpo(active.corpo);
    setAssunto(active.assunto);
    setDirty(false);
  }, [activeId]);

  // se o modelo ativo foi removido, seleciona o primeiro
  React.useEffect(() => {
    if (!templates.find((t) => t.id === activeId) && templates[0]) setActiveId(templates[0].id);
  }, [templates.length]);

  if (!active) {
    return <div className="cj-card cj-card--pad" style={{ textAlign: "center", padding: "var(--space-12)" }}>
      <p className="cj-muted">Nenhum modelo. <a href="#" onClick={(e) => { e.preventDefault(); const n = CJStore.addTemplate({}); setActiveId(n.id); }}>Criar o primeiro</a>.</p>
    </div>;
  }

  function novoModelo() { const n = CJStore.addTemplate({}); setActiveId(n.id); pushToast({ variant: "success", title: "Modelo criado", msg: "Edite o conteúdo e salve." }); }
  function duplicar() { const n = CJStore.duplicateTemplate(active.id); if (n) { setActiveId(n.id); pushToast({ variant: "success", title: "Modelo duplicado" }); } }
  function salvar() { CJStore.saveTemplate(active.id, { corpo, assunto }); setDirty(false); pushToast({ variant: "success", title: "Modelo salvo", msg: "As alterações foram aplicadas." }); }
  function alternarAtivo() { CJStore.toggleTemplate(active.id); pushToast({ variant: "info", title: active.ativo ? "Modelo desativado" : "Modelo ativado" }); }
  function excluir() { const id = active.id; CJStore.removeTemplate(id); pushToast({ variant: "danger", title: "Modelo excluído" }); }

  const VAR_GROUPS = [
    { grupo: "Dados do devedor", vars: [
      { tag: "{{nome}}", label: "Nome" },
      { tag: "{{fatura}}", label: "Nº da fatura" },
      { tag: "{{valor}}", label: "Valor do débito" },
      { tag: "{{vencimento}}", label: "Vencimento" },
      { tag: "{{dias}}", label: "Dias de atraso" },
      { tag: "{{empresa}}", label: "Empresa" },
      { tag: "{{cnpj}}", label: "CNPJ" },
    ] },
    { grupo: "Facilitar pagamento", vars: [
      { tag: "{{pix_copia_cola}}", label: "Pix copia e cola (valor já preenchido)" },
      { tag: "{{link_acordo}}", label: "Link de autoatendimento de acordo" },
      { tag: "{{prazo_limite}}", label: "Prazo limite (hoje + 5 dias úteis)" },
      { tag: "{{valor_desconto}}", label: "Valor com desconto (à vista)" },
    ] },
  ];

  function insertVar(tag) {
    const ta = taRef.current;
    setDirty(true);
    if (!ta) { setCorpo((c) => c + tag); return; }
    const s = ta.selectionStart, e = ta.selectionEnd;
    const next = corpo.slice(0, s) + tag + corpo.slice(e);
    setCorpo(next);
    requestAnimationFrame(() => { ta.focus(); ta.selectionStart = ta.selectionEnd = s + tag.length; });
  }

  // resolve preview with sample data (devedor exemplo)
  const exemplo = { id: "FAT-2024-0182", nome: "Marcos Antônio Pereira", valor: 4820.50, dias: 47 };
  const sample = {
    "{{nome}}": exemplo.nome,
    "{{fatura}}": exemplo.id,
    "{{valor}}": "R$ 4.820,50",
    "{{valor_desconto}}": "R$ 2.892,30",
    "{{vencimento}}": "10/05/2026",
    "{{dias}}": "47",
    "{{empresa}}": "Aurora Peças & Diesel",
    "{{cnpj}}": "12.345.678/0001-90",
    "{{prazo_limite}}": (typeof cjPrazoLimite === "function" ? cjPrazoLimite(5) : "17 de junho de 2026"),
    "{{link_acordo}}": "cobrajuris.app/acordo/40182",
    "{{pix_copia_cola}}": "00020126360014BR.GOV.BCB.PIX…5802BR…6304A1B2",
  };
  const resolved = corpo.replace(/\{\{\w+\}\}/g, (m) => sample[m] || m);
  const resolvedSubject = assunto.replace(/\{\{\w+\}\}/g, (m) => sample[m] || m);

  return (
    <div className="cj-editor">
      {/* LEFT — template list */}
      <div className="cj-editor__list">
        <div className="cj-editor__list-head">
          <span className="cj-editor__list-title">Modelos</span>
          <button className="cj-iconbtn cj-iconbtn--sm cj-iconbtn--outline" title="Novo modelo" onClick={novoModelo}><CJIcon name="plus" size={16} /></button>
        </div>
        <div style={{ overflowY: "auto" }}>
          {templates.map((t) => {
            const cn = CJ_CANAL_LABEL[t.canal];
            return (
              <button key={t.id} className={"cj-tplitem" + (t.id === activeId ? " cj-tplitem--active" : "")} onClick={() => setActiveId(t.id)}>
                <div className="cj-tplitem__name">{t.nome}</div>
                <div className="cj-tplitem__meta">
                  <span className={`cj-canal cj-canal--${t.canal}`}><CJIcon name={cn.icon} size={13} /> {cn.label}</span>
                  {!t.ativo && <Badge variant="neutral">Inativo</Badge>}
                  <span className="cj-tplitem__uses">{t.usos} usos</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* CENTER — editor */}
      <div className="cj-editor__main">
        <div className="cj-row" style={{ justifyContent: "space-between", gap: "var(--space-3)" }}>
          <div className="cj-stack" style={{ minWidth: 0 }}>
            <input className="cj-input" value={active.nome} readOnly style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "var(--text-md)", border: "none", padding: 0, height: "auto", background: "transparent" }} />
            <div className="cj-row cj-gap-2" style={{ marginTop: 4 }}>
              <span className={`cj-canal cj-canal--${active.canal}`}><CJIcon name={CJ_CANAL_LABEL[active.canal].icon} size={14} /> {CJ_CANAL_LABEL[active.canal].label}</span>
              <span className="cj-muted" style={{ fontSize: "var(--text-xs)" }}>· Tom {active.tom}</span>
            </div>
          </div>
          <div className="cj-row cj-gap-2">
            <Button variant="ghost" size="sm" onClick={alternarAtivo}>{active.ativo ? "Desativar" : "Ativar"}</Button>
            <Button variant="ghost" size="sm" leftIcon={<CJIcon name="copy" size={15} />} onClick={duplicar}>Duplicar</Button>
            <Button variant="ghost" size="sm" leftIcon={<CJIcon name="trash" size={15} />} onClick={excluir}>Excluir</Button>
            <Button size="sm" leftIcon={<CJIcon name="check" size={15} />} onClick={salvar}>{dirty ? "Salvar*" : "Salvar"}</Button>
          </div>
        </div>

        {active.canal === "email" && (
          <Input label="Assunto do e-mail" value={assunto} onChange={(e) => { setAssunto(e.target.value); setDirty(true); }} />
        )}

        <div className="cj-stack" style={{ flex: 1, gap: "var(--space-2)" }}>
          <label className="cj-label">Corpo da mensagem</label>
          <div className="cj-editor__toolbar">
            {VAR_GROUPS.map((g) => (
              <div key={g.grupo} className="cj-vargroup">
                <span className="cj-vargroup__label">{g.grupo}</span>
                <div className="cj-vargroup__chips">
                  {g.vars.map((v) => (
                    <button key={v.tag} className={"cj-var" + (g.grupo === "Facilitar pagamento" ? " cj-var--pay" : "")} onClick={() => insertVar(v.tag)} title={v.label}>{v.tag}</button>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <textarea ref={taRef} className="cj-editor__textarea" value={corpo} onChange={(e) => { setCorpo(e.target.value); setDirty(true); }} />
          <div className="cj-row" style={{ justifyContent: "space-between" }}>
            <span className="cj-muted" style={{ fontSize: "var(--text-xs)" }}>{corpo.length} caracteres{active.canal === "sms" ? ` · ${Math.ceil(corpo.length / 160)} SMS` : ""}</span>
            <span className="cj-muted" style={{ fontSize: "var(--text-xs)" }}>Variáveis substituídas no envio</span>
          </div>
        </div>
      </div>

      {/* RIGHT — preview */}
      <div className="cj-editor__preview">
        <span className="cj-editor__preview-head">Pré-visualização</span>

        {active.canal === "email" ? (
          <div className="cj-emailprev">
            <div className="cj-emailprev__head">
              <div className="cj-emailprev__subject">{resolvedSubject}</div>
              <div className="cj-emailprev__from">de Aurora Peças & Diesel · para financeiro@autodieselcenter.com.br</div>
            </div>
            <div className="cj-emailprev__body">{resolved}</div>
          </div>
        ) : (
          <div className="cj-wa">
            <div className="cj-wa__bar">
              <span className="cj-wa__bar-avatar">AP</span>
              <div className="cj-stack">
                <span className="cj-wa__bar-name">Aurora Peças</span>
                <span className="cj-wa__bar-status">conta comercial · online</span>
              </div>
              <div style={{ marginLeft: "auto", display: "flex", gap: 12, opacity: 0.85 }}>
                <CJIcon name="phone" size={16} /><CJIcon name="more" size={16} />
              </div>
            </div>
            <div className="cj-wa__phone cj-wa__body">
              <div className="cj-wa__bubble">
                {resolved}
                <span className="cj-wa__time">09:14 ✓✓</span>
              </div>
            </div>
          </div>
        )}

        <div className="cj-card cj-card--pad" style={{ padding: "var(--space-4)" }}>
          <div className="cj-row" style={{ justifyContent: "space-between", marginBottom: 8 }}>
            <span className="cj-muted" style={{ fontSize: "var(--text-xs)", fontWeight: 700 }}>Desempenho do modelo</span>
          </div>
          <div className="cj-row" style={{ gap: "var(--space-5)" }}>
            <div className="cj-stack"><span style={{ fontWeight: 700, color: "var(--text-strong)", fontFamily: "var(--font-mono)" }}>{active.usos}</span><span className="cj-muted" style={{ fontSize: "var(--text-2xs)" }}>Envios</span></div>
            <div className="cj-stack"><span style={{ fontWeight: 700, color: "var(--success-600)", fontFamily: "var(--font-mono)" }}>41%</span><span className="cj-muted" style={{ fontSize: "var(--text-2xs)" }}>Resposta</span></div>
            <div className="cj-stack"><span style={{ fontWeight: 700, color: "var(--text-strong)", fontFamily: "var(--font-mono)" }}>18%</span><span className="cj-muted" style={{ fontSize: "var(--text-2xs)" }}>Acordo</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}

window.MensagensScreen = MensagensScreen;
