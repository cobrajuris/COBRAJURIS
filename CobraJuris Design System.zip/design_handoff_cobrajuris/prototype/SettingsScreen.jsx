/* CobraJuris — Configurações. Tela em modo ESCURO (fundo escuro)
   com destaque em VERDE LODO (olive). Abre em camada própria,
   sobre o app, com seu próprio tema escoado em .cj-set. */

function SettingsScreen({ onClose, pushToast }) {
  const [tab, setTab] = React.useState("geral");
  const [tema, setTema] = React.useState("escuro"); // escuro | claro
  const [canais, setCanais] = React.useState({ whatsapp: true, sms: true, email: true });
  const [acento, setAcento] = React.useState("lodo");
  const [cadMin, setCadMin] = React.useState(8);
  const [cadMax, setCadMax] = React.useState(25);
  const [spintax, setSpintax] = React.useState(true);
  const [aquecimento, setAquecimento] = React.useState(true);
  const [optout, setOptout] = React.useState(true);
  const [autopausa, setAutopausa] = React.useState(true);
  const [limiteDia, setLimiteDia] = React.useState(80);

  const TABS = [
    { key: "geral", label: "Geral", icon: "building" },
    { key: "canais", label: "Canais", icon: "send" },
    { key: "horario", label: "Horários", icon: "clock" },
    { key: "protecao", label: "Proteção", icon: "zap" },
    { key: "aparencia", label: "Aparência", icon: "eye" },
  ];

  const ACENTOS = [
    { key: "lodo", label: "Verde lodo", color: "#8B9B4E" },
    { key: "esmeralda", label: "Esmeralda", color: "#1B8761" },
    { key: "musgo", label: "Musgo", color: "#5E6B33" },
  ];
  const acentoColor = ACENTOS.find((a) => a.key === acento).color;

  function toggleCanal(k) { setCanais((p) => ({ ...p, [k]: !p[k] })); }
  function salvar() { pushToast({ variant: "success", title: "Configurações salvas", msg: tab === "protecao" ? "Cadência, spintax e proteções atualizadas." : "As preferências da empresa foram atualizadas." }); }

  return (
    <div className={"cj-set" + (tema === "claro" ? " cj-set--claro" : "")} style={{ "--lodo": acentoColor }}>
      {/* top bar */}
      <header className="cj-set__top">
        <div className="cj-set__brand">
          <div className="cj-stack">
            <span className="cj-set__brand-name">Cobra<span style={{ color: "var(--lodo)" }}>Juris</span></span>
            <span className="cj-set__brand-sub">Configurações da empresa</span>
          </div>
        </div>
        <button className="cj-set__close" onClick={onClose}>
          <CJIcon name="x" size={18} /> Fechar
        </button>
      </header>

      <div className="cj-set__body">
        {/* nav */}
        <nav className="cj-set__nav">
          {TABS.map((t) => (
            <button key={t.key} className={"cj-set__navitem" + (tab === t.key ? " cj-set__navitem--active" : "")} onClick={() => setTab(t.key)}>
              <CJIcon name={t.icon} size={18} /> <span>{t.label}</span>
            </button>
          ))}
        </nav>

        {/* content */}
        <div className="cj-set__content">
          {tab === "geral" && (
            <React.Fragment>
              <SetSection title="Dados da empresa" desc="Aparecem no rodapé das mensagens enviadas.">
                <SetField label="Razão social"><input className="cj-set__input" defaultValue="Aurora Peças & Diesel Ltda" /></SetField>
                <div className="cj-set__grid2">
                  <SetField label="CNPJ"><input className="cj-set__input" defaultValue="29.481.330/0001-55" /></SetField>
                  <SetField label="CNPJ"><input className="cj-set__input" defaultValue="12.345.678/0001-90" /></SetField>
                </div>
                <SetField label="E-mail de contato"><input className="cj-set__input" defaultValue="contato@auroracaminhoes.com.br" /></SetField>
              </SetSection>
              <SetSection title="Assinatura padrão" desc="Substitui a variável {{empresa}} nos modelos.">
                <textarea className="cj-set__input cj-set__textarea" defaultValue={"Atenciosamente,\nAurora Peças & Diesel Ltda\n(11) 3030-1180"} />
              </SetSection>
            </React.Fragment>
          )}

          {tab === "canais" && (
            <SetSection title="Canais de disparo" desc="Ative os canais usados nas réguas de cobrança.">
              {[
                { k: "whatsapp", icon: "whatsapp", nome: "WhatsApp Business", sub: "Conta verificada · +55 11 99988-1180" },
                { k: "sms", icon: "smartphone", nome: "SMS", sub: "Operadora integrada · 1.240 créditos" },
                { k: "email", icon: "mail", nome: "E-mail", sub: "SMTP · disparos@auroracaminhoes.com.br" },
              ].map((c) => (
                <div key={c.k} className="cj-set__channel">
                  <span className="cj-set__channel-icon"><CJIcon name={c.icon} size={20} /></span>
                  <div className="cj-stack" style={{ flex: 1 }}>
                    <span className="cj-set__channel-name">{c.nome}</span>
                    <span className="cj-set__channel-sub">{c.sub}</span>
                  </div>
                  <SetSwitch on={canais[c.k]} onClick={() => toggleCanal(c.k)} />
                </div>
              ))}
            </SetSection>
          )}

          {tab === "horario" && (
            <SetSection title="Janela de disparo" desc="O sistema respeita estes limites e não dispara em feriados.">
              <div className="cj-set__grid2">
                <SetField label="Início"><input type="time" className="cj-set__input" defaultValue="08:00" /></SetField>
                <SetField label="Fim"><input type="time" className="cj-set__input" defaultValue="20:00" /></SetField>
              </div>
              <SetField label="Limite diário por canal"><input className="cj-set__input" type="number" defaultValue="80" /></SetField>
              <div className="cj-set__channel" style={{ marginTop: 4 }}>
                <div className="cj-stack" style={{ flex: 1 }}>
                  <span className="cj-set__channel-name">Não disparar em feriados nacionais</span>
                  <span className="cj-set__channel-sub">Calendário ANBIMA</span>
                </div>
                <SetSwitch on={true} onClick={() => {}} />
              </div>
            </SetSection>
          )}

          {tab === "protecao" && (
            <React.Fragment>
              <SetSection title="Cadência de disparo" desc="Espaçamento aleatório entre mensagens para imitar envio humano e proteger o número contra bloqueio.">
                <div className="cj-set__cadence">
                  <div className="cj-set__cadence-val">
                    <span className="cj-set__cadence-num">{cadMin}–{cadMax}s</span>
                    <span className="cj-set__channel-sub">intervalo entre cada envio</span>
                  </div>
                  <div className="cj-stack" style={{ gap: 14, flex: 1 }}>
                    <SetField label={`Mínimo: ${cadMin}s`}>
                      <input type="range" className="cj-set__range" min={3} max={cadMax - 1} value={cadMin} onChange={(e) => setCadMin(+e.target.value)} />
                    </SetField>
                    <SetField label={`Máximo: ${cadMax}s`}>
                      <input type="range" className="cj-set__range" min={cadMin + 1} max={90} value={cadMax} onChange={(e) => setCadMax(+e.target.value)} />
                    </SetField>
                  </div>
                </div>
                <div className="cj-set__hint-row"><CJIcon name="alert" size={14} /> Cerca de <strong>{Math.round(3600 / ((cadMin + cadMax) / 2))}</strong> mensagens por hora, por número.</div>
              </SetSection>

              <SetSection title="Variação de texto (Spintax)" desc="Gera frases ligeiramente diferentes por devedor. O WhatsApp pune mensagens idênticas em massa — variar reduz muito o risco.">
                <div className="cj-set__channel">
                  <span className="cj-set__channel-icon"><CJIcon name="refresh" size={20} /></span>
                  <div className="cj-stack" style={{ flex: 1 }}>
                    <span className="cj-set__channel-name">Ativar spintax automático</span>
                    <span className="cj-set__channel-sub">{"{Olá|Bom dia|Prezado}, {{nome}}…"}</span>
                  </div>
                  <SetSwitch on={spintax} onClick={() => setSpintax(!spintax)} />
                </div>
                {spintax && (
                  <div className="cj-set__spinprev">
                    <span className="cj-set__channel-sub">Pré-visualização de 3 variações:</span>
                    <div className="cj-set__spinex">Olá, Marcos! Consta uma pendência…</div>
                    <div className="cj-set__spinex">Bom dia, Marcos. Identificamos um débito…</div>
                    <div className="cj-set__spinex">Prezado Marcos, há um valor em aberto…</div>
                  </div>
                )}
              </SetSection>

              <SetSection title="Aquecimento e segurança" desc="Proteções automáticas aplicadas a cada número conectado.">
                <SetField label={`Limite diário inicial por número: ${limiteDia}/dia`}>
                  <input type="range" className="cj-set__range" min={20} max={400} step={10} value={limiteDia} onChange={(e) => setLimiteDia(+e.target.value)} />
                </SetField>
                <div className="cj-set__channel">
                  <div className="cj-stack" style={{ flex: 1 }}>
                    <span className="cj-set__channel-name">Aquecimento progressivo</span>
                    <span className="cj-set__channel-sub">Sobe o limite aos poucos em números novos</span>
                  </div>
                  <SetSwitch on={aquecimento} onClick={() => setAquecimento(!aquecimento)} />
                </div>
                <div className="cj-set__channel">
                  <div className="cj-stack" style={{ flex: 1 }}>
                    <span className="cj-set__channel-name">Opt-out automático</span>
                    <span className="cj-set__channel-sub">“Responda SAIR” remove o contato da régua</span>
                  </div>
                  <SetSwitch on={optout} onClick={() => setOptout(!optout)} />
                </div>
                <div className="cj-set__channel">
                  <div className="cj-stack" style={{ flex: 1 }}>
                    <span className="cj-set__channel-name">Pausa automática por risco</span>
                    <span className="cj-set__channel-sub">Para sozinho se a entrega cair ou subir bloqueios</span>
                  </div>
                  <SetSwitch on={autopausa} onClick={() => setAutopausa(!autopausa)} />
                </div>
              </SetSection>
            </React.Fragment>
          )}

          {tab === "aparencia" && (
            <React.Fragment>
              <SetSection title="Tema" desc="O escuro usa o fundo escuro; o destaque é o verde lodo.">
                <div className="cj-set__themegrid">
                  <button className={"cj-set__themecard cj-set__themecard--dark" + (tema === "escuro" ? " is-on" : "")} onClick={() => setTema("escuro")}>
                    <span className="cj-set__theme-prev cj-set__theme-prev--dark"><i style={{ background: "var(--lodo)" }}></i></span>
                    <span className="cj-set__theme-label">Escuro <CJIcon name={tema === "escuro" ? "checkCircle" : "circle"} size={15} /></span>
                  </button>
                  <button className={"cj-set__themecard cj-set__themecard--light" + (tema === "claro" ? " is-on" : "")} onClick={() => setTema("claro")}>
                    <span className="cj-set__theme-prev cj-set__theme-prev--light"><i style={{ background: "var(--lodo)" }}></i></span>
                    <span className="cj-set__theme-label">Claro <CJIcon name={tema === "claro" ? "checkCircle" : "circle"} size={15} /></span>
                  </button>
                </div>
              </SetSection>
              <SetSection title="Cor de destaque" desc="Aplicada a botões, links e estados ativos.">
                <div className="cj-set__swatches">
                  {ACENTOS.map((a) => (
                    <button key={a.key} className={"cj-set__swatch" + (acento === a.key ? " is-on" : "")} onClick={() => setAcento(a.key)}>
                      <span style={{ background: a.color }}></span>{a.label}
                    </button>
                  ))}
                </div>
              </SetSection>
            </React.Fragment>
          )}

          <div className="cj-set__actions">
            <button className="cj-set__btn cj-set__btn--ghost" onClick={onClose}>Cancelar</button>
            <button className="cj-set__btn cj-set__btn--primary" onClick={salvar}><CJIcon name="check" size={16} /> Salvar alterações</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function SetSection({ title, desc, children }) {
  return (
    <section className="cj-set__section">
      <div className="cj-set__section-head">
        <h2 className="cj-set__section-title">{title}</h2>
        {desc && <p className="cj-set__section-desc">{desc}</p>}
      </div>
      <div className="cj-stack" style={{ gap: 16 }}>{children}</div>
    </section>
  );
}
function SetField({ label, children }) {
  return (<label className="cj-set__field"><span className="cj-set__label">{label}</span>{children}</label>);
}
function SetSwitch({ on, onClick }) {
  return (<button className={"cj-set__switch" + (on ? " is-on" : "")} onClick={onClick} aria-pressed={on}><span className="cj-set__switch-thumb"></span></button>);
}

// extra icon used here
if (window.CJ_ICON_NAMES && !window.CJ_ICON_NAMES.includes("circle")) { /* circle fallback handled in icons */ }

window.SettingsScreen = SettingsScreen;
