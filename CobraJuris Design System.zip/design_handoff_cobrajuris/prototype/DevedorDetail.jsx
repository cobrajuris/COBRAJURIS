/* CobraJuris — Detalhe do devedor. Drawer lateral aberto pela busca
   (ou pela ação "ver" na lista). Mostra dados, contato, KPIs e o
   histórico de mensagens disparadas. */

function DevedorDetail({ devedor, onClose, onNav, onOpenChat, pushToast }) {
  if (!devedor) return null;
  const d = devedor;
  const st = CJ_STATUS_LABEL[d.status];
  const cn = CJ_CANAL_LABEL[d.canal];

  // histórico sintético coerente com a situação
  const base = [
    { ic: "upload", tone: "var(--text-muted)", titulo: "Devedor importado", sub: "Adicionado via planilha Excel", quando: "Há 9 dias" },
    { ic: cn.icon, tone: "var(--green-600)", titulo: `Lembrete amigável enviado · ${cn.label}`, sub: "Modelo: 1º contato", quando: "Há 2 dias" },
    { ic: "checkCircle", tone: "var(--info-600)", titulo: "Mensagem entregue", sub: "Confirmação de entrega", quando: "Há 2 dias" },
  ];
  const extra = {
    paid:    [{ ic: "dollar", tone: "var(--success-600)", titulo: "Pagamento confirmado", sub: "Débito quitado integralmente", quando: "Há 5 dias" }],
    overdue: [{ ic: "alert", tone: "var(--danger-600)", titulo: "Cobrança formal agendada", sub: "Régua: atrasos 30+ dias", quando: "Amanhã, 09:00" }],
    pending: [{ ic: "clock", tone: "var(--warning-600)", titulo: "Próximo disparo agendado", sub: "Régua: a vencer", quando: "Em 2 dias" }],
    sent:    [{ ic: "eye", tone: "var(--info-600)", titulo: "Mensagem lida", sub: "Visualizada pelo devedor", quando: "Há 1 dia" }],
    scheduled: [{ ic: "calendar", tone: "var(--text-secondary)", titulo: "Disparo agendado", sub: "Aguardando janela de envio", quando: "Hoje, 14:00" }],
  };
  const timeline = [...(extra[d.status] || []), ...base];

  return (
    <React.Fragment>
      <div className="cj-drawer-overlay" onClick={onClose}></div>
      <aside className="cj-drawer" role="dialog" aria-label={`Detalhes de ${d.nome}`}>
        <header className="cj-drawer__head">
          <button className="cj-iconbtn cj-iconbtn--sm" onClick={onClose} title="Fechar"><CJIcon name="x" size={18} /></button>
          <span className="cj-drawer__head-id">{d.id}</span>
        </header>

        <div className="cj-drawer__id">
          <div className="cj-avatar cj-avatar--lg">{initials(d.nome)}</div>
          <div className="cj-stack" style={{ gap: 4, flex: 1, minWidth: 0 }}>
            <button className="cj-drawer__name cj-namecell__link" onClick={() => onOpenChat && onOpenChat(d)} title="Abrir conversa" style={{ textAlign: "left" }}>{d.nome}</button>
            <span className="cj-namecell__meta" style={{ fontSize: "var(--text-sm)" }}>{d.doc}</span>
          </div>
          <span className={`cj-badge cj-badge--${st.badge}`} style={{ flex: "none", alignSelf: "flex-start" }}><span className="cj-badge__dot"></span>{st.label}</span>
        </div>

        <div className="cj-drawer__kpis">
          <div className="cj-drawer__kpi"><span className="cj-drawer__kpi-label">Valor do débito</span><span className="cj-drawer__kpi-value tnum">{CJ_FMT(d.valor)}</span></div>
          <div className="cj-drawer__kpi"><span className="cj-drawer__kpi-label">Parcela</span><span className="cj-drawer__kpi-value">{d.parcelas}</span></div>
          <div className="cj-drawer__kpi"><span className="cj-drawer__kpi-label">Atraso</span><span className="cj-drawer__kpi-value" style={{ color: d.dias > 30 ? "var(--danger-600)" : "var(--text-strong)" }}>{d.dias > 0 ? d.dias + " dias" : "—"}</span></div>
        </div>

        <div className="cj-drawer__section">
          <span className="cj-drawer__section-label">Contato</span>
          <div className="cj-drawer__contact">
            <span className={`cj-canal cj-canal--${d.canal}`}><CJIcon name={cn.icon} size={16} /> {cn.label}</span>
            <span className="cj-drawer__contact-val">{d.tel}</span>
          </div>
        </div>

        <div className="cj-drawer__section" style={{ flex: 1, minHeight: 0, overflowY: "auto" }}>
          <span className="cj-drawer__section-label">Histórico de cobrança</span>
          <div className="cj-timeline">
            {timeline.map((t, i) => (
              <div key={i} className="cj-tl-item">
                <span className="cj-tl-dot" style={{ color: t.tone }}><CJIcon name={t.ic} size={14} /></span>
                {i < timeline.length - 1 && <span className="cj-tl-line"></span>}
                <div className="cj-stack" style={{ gap: 2, paddingBottom: 18 }}>
                  <span className="cj-tl-title">{t.titulo}</span>
                  <span className="cj-tl-sub">{t.sub}</span>
                  <span className="cj-tl-when">{t.quando}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <footer className="cj-drawer__foot">
          <button className="cj-btn cj-btn--secondary cj-btn--md" onClick={() => { CJStore.markPaid(d.id); pushToast({ variant: "success", title: "Pagamento registrado", msg: `${shortName(d.nome)} marcado como quitado.` }); }}><CJIcon name="dollar" size={16} />Registrar pagamento</button>
          <button className="cj-btn cj-btn--primary cj-btn--md" style={{ flex: 1 }} onClick={() => { onClose(); onOpenChat && onOpenChat(d); }}><CJIcon name="message" size={16} />Abrir conversa</button>
        </footer>
      </aside>
    </React.Fragment>
  );
}

window.DevedorDetail = DevedorDetail;
