/* CobraJuris — Login screen. Split layout: brand panel + form.
   onLogin() advances the demo into the app. */

function LoginScreen({ onLogin }) {
  const { Button, Input, Checkbox } = window.CobraJurisDesignSystem_4e03fb;
  const [email, setEmail] = React.useState("financeiro@auroracaminhoes.com.br");
  const [senha, setSenha] = React.useState("••••••••••");

  function submit(e) {
    e.preventDefault();
    onLogin();
  }

  return (
    <div className="cj-login">
      <div className="cj-login__aside">
        <div className="cj-login__aside-grid"></div>
        <div className="cj-login__brand">
          <span className="cj-wordmark__text">Cobra<span className="cj-wordmark__accent">Juris</span></span>
        </div>

        <div className="cj-login__lead">
          <div className="cj-login__eyebrow">Cobrança automatizada para empresas</div>
          <h2 className="cj-login__headline">Reduza a inadimplência da sua empresa com réguas de cobrança automáticas.</h2>
          <p className="cj-login__sub">
            Importe sua planilha de clientes, defina os modelos de mensagem e agende os disparos por
            WhatsApp, SMS e e-mail. Seu time foca no acordo — a régua roda sozinha.
          </p>
        </div>

        <div className="cj-login__stats">
          <div>
            <div className="cj-login__stat-value tnum">R$ 1,8M</div>
            <div className="cj-login__stat-label">Recuperados no mês</div>
          </div>
          <div>
            <div className="cj-login__stat-value tnum">14.200</div>
            <div className="cj-login__stat-label">Disparos enviados</div>
          </div>
          <div>
            <div className="cj-login__stat-value tnum">38%</div>
            <div className="cj-login__stat-label">Taxa de resposta</div>
          </div>
        </div>
      </div>

      <div className="cj-login__panel">
        <form className="cj-login__form" onSubmit={submit}>
          <h1 className="cj-login__title">Acessar o painel</h1>
          <p className="cj-login__hint">Bem-vindo de volta. Entre com as credenciais da sua empresa.</p>

          <div className="cj-login__fields">
            <Input
              label="E-mail profissional"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              leadingIcon={<CJIcon name="mail" size={18} />}
            />
            <div className="cj-stack" style={{ gap: "var(--space-2)" }}>
              <Input
                label="Senha"
                type="password"
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
                leadingIcon={<CJIcon name="lock" size={18} />}
              />
              <div className="cj-login__row">
                <Checkbox label="Manter conectado" defaultChecked />
                <a href="#" onClick={(e) => e.preventDefault()} style={{ fontSize: "var(--text-sm)", fontWeight: 700 }}>Esqueci a senha</a>
              </div>
            </div>

            <Button type="submit" size="lg" block rightIcon={<CJIcon name="arrowRight" size={18} />}>
              Entrar no painel
            </Button>
          </div>

          <div className="cj-login__demo">
            Demonstração — clique em <strong>Entrar</strong> para explorar o produto.
          </div>

          <p className="cj-login__foot">
            Ainda não tem conta? <a href="#" onClick={(e) => e.preventDefault()}>Falar com vendas</a>
          </p>
        </form>
      </div>
    </div>
  );
}

window.LoginScreen = LoginScreen;
