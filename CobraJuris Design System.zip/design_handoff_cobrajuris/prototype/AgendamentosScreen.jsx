/* CobraJuris — Agendamentos. Active dispatch schedules (réguas)
   plus an inline "nova régua" composer with day/time/channel controls. */

function AgendamentosScreen({ pushToast }) {
  const DS = window.CobraJurisDesignSystem_4e03fb;
  const { Button, Badge } = DS;
  const { agendamentos, templates } = useCJ();

  const DIAS = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"];
  const [novoDias, setNovoDias] = React.useState(() => new Set(["Seg", "Qua", "Sex"]));
  const [hora, setHora] = React.useState("09:00");
  const [canal, setCanal] = React.useState("whatsapp");
  const [nome, setNome] = React.useState("Lembrete — vencidos esta semana");
  const [tplId, setTplId] = React.useState(templates[0] && templates[0].id);
  const schedules = agendamentos;

  function toggleDia(d) {
    setNovoDias((prev) => { const n = new Set(prev); n.has(d) ? n.delete(d) : n.add(d); return n; });
  }
  function toggleStatus(id) {
    const s = schedules.find((x) => x.id === id);
    CJStore.toggleAgendamento(id);
    pushToast({ variant: "info", title: s && s.status === "ativo" ? "Régua pausada" : "Régua retomada" });
  }
  function excluir(id) {
    CJStore.removeAgendamento(id);
    pushToast({ variant: "danger", title: "Régua excluída" });
  }
  function criar() {
    if (!nome.trim() || novoDias.size === 0) { pushToast({ variant: "danger", title: "Preencha nome e dias" }); return; }
    const tpl = templates.find((t) => t.id === tplId) || templates[0];
    const diasOrd = DIAS.filter((d) => novoDias.has(d));
    CJStore.addAgendamento({ nome: nome.trim(), template: tpl ? tpl.nome : "—", canal, hora, dias: diasOrd, alvos: 0 });
    CJStore.pushNotif({ tipo: "alert", canal, titulo: "Régua criada", texto: `“${nome.trim()}” entrou na fila de disparos.` });
    pushToast({ variant: "success", title: "Régua criada", msg: "A nova régua está ativa e entrará na fila." });
    setNome("Nova régua de cobrança");
  }

  return (
    <div className="cj-grid" style={{ gridTemplateColumns: "1.55fr 1fr", gap: "var(--space-6)", alignItems: "start" }}>
      {/* LEFT — active schedules */}
      <div className="cj-stack" style={{ gap: "var(--space-5)" }}>
        <div className="cj-section__head" style={{ marginBottom: 0 }}>
          <div className="cj-section__title">Réguas de cobrança</div>
          <Badge variant="brand">{schedules.filter((s) => s.status === "ativo").length} ativas</Badge>
        </div>

        {schedules.map((s) => {
          const cn = CJ_CANAL_LABEL[s.canal];
          const ativo = s.status === "ativo";
          return (
            <div key={s.id} className="cj-card cj-schedcard">
              <div className="cj-schedcard__head">
                <span style={{ width: 42, height: 42, borderRadius: 12, flex: "none", background: ativo ? "var(--green-50)" : "var(--surface-subtle)", color: ativo ? "var(--green-600)" : "var(--text-muted)", display: "inline-flex", alignItems: "center", justifyContent: "center" }}>
                  <CJIcon name="zap" size={20} />
                </span>
                <div className="cj-stack" style={{ flex: 1 }}>
                  <span className="cj-schedcard__title">{s.nome}</span>
                  <span className="cj-schedcard__tpl">Modelo: {s.template}</span>
                </div>
                <Badge variant={ativo ? "success" : "neutral"} dot>{ativo ? "Ativa" : "Pausada"}</Badge>
              </div>

              <div className="cj-schedcard__grid">
                <div>
                  <div className="cj-schedcard__field-label">Canal</div>
                  <div className="cj-schedcard__field-value"><span className={`cj-canal cj-canal--${s.canal}`}><CJIcon name={cn.icon} size={15} /> {cn.label}</span></div>
                </div>
                <div>
                  <div className="cj-schedcard__field-label">Horário</div>
                  <div className="cj-schedcard__field-value"><CJIcon name="clock" size={14} /> {s.hora}</div>
                </div>
                <div>
                  <div className="cj-schedcard__field-label">Dias</div>
                  <div className="cj-daypills" style={{ marginTop: 4 }}>
                    {DIAS.map((d) => <span key={d} className={"cj-daypill" + (s.dias.includes(d) ? " cj-daypill--on" : "")}>{d[0]}</span>)}
                  </div>
                </div>
                <div>
                  <div className="cj-schedcard__field-label">Alvos na fila</div>
                  <div className="cj-schedcard__field-value tnum">{s.alvos} devedores</div>
                </div>
              </div>

              <div className="cj-schedcard__foot">
                <span className="cj-nextrun"><CJIcon name="calendar" size={14} /> Próximo disparo: <strong>{s.proximo}</strong></span>
                <div className="cj-row cj-gap-2">
                  <Button variant="ghost" size="sm" leftIcon={<CJIcon name="trash" size={15} />} onClick={() => excluir(s.id)}>Excluir</Button>
                  <Button variant="secondary" size="sm" leftIcon={<CJIcon name={ativo ? "pause" : "play"} size={15} />} onClick={() => toggleStatus(s.id)}>
                    {ativo ? "Pausar" : "Retomar"}
                  </Button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* RIGHT — new schedule composer */}
      <div className="cj-card cj-card--pad" style={{ position: "sticky", top: "calc(var(--topbar-height) + var(--space-6))" }}>
        <div className="cj-row cj-gap-3" style={{ marginBottom: "var(--space-5)" }}>
          <span style={{ width: 38, height: 38, borderRadius: 10, background: "var(--green-600)", color: "#fff", display: "inline-flex", alignItems: "center", justifyContent: "center", flex: "none" }}><CJIcon name="plus" size={18} /></span>
          <div className="cj-stack">
            <span className="cj-section__title">Nova régua</span>
            <span className="cj-muted" style={{ fontSize: "var(--text-xs)" }}>Agende disparos automáticos</span>
          </div>
        </div>

        <div className="cj-field" style={{ marginBottom: "var(--space-4)" }}>
          <label className="cj-label">Nome da régua</label>
          <input className="cj-input" value={nome} onChange={(e) => setNome(e.target.value)} />
        </div>

        <div className="cj-field" style={{ marginBottom: "var(--space-4)" }}>
          <label className="cj-label">Modelo de mensagem</label>
          <select className="cj-select" value={tplId} onChange={(e) => setTplId(e.target.value)}>
            {templates.map((t) => <option key={t.id} value={t.id}>{t.nome}</option>)}
          </select>
        </div>

        <div className="cj-field" style={{ marginBottom: "var(--space-4)" }}>
          <label className="cj-label">Canal</label>
          <div className="cj-row cj-gap-2">
            {Object.entries(CJ_CANAL_LABEL).map(([k, v]) => (
              <button key={k} className={"cj-chip" + (canal === k ? " cj-chip--active" : "")} onClick={() => setCanal(k)} style={{ flex: 1, justifyContent: "center" }}>
                <CJIcon name={v.icon} size={15} /> {v.label}
              </button>
            ))}
          </div>
        </div>

        <div className="cj-field" style={{ marginBottom: "var(--space-4)" }}>
          <label className="cj-label">Dias da semana</label>
          <div className="cj-daypills">
            {DIAS.map((d) => (
              <button key={d} className={"cj-daypill" + (novoDias.has(d) ? " cj-daypill--on" : "")} onClick={() => toggleDia(d)} style={{ width: 34, height: 34, cursor: "pointer" }}>{d[0]}</button>
            ))}
          </div>
        </div>

        <div className="cj-row cj-gap-3" style={{ marginBottom: "var(--space-5)" }}>
          <div className="cj-field" style={{ flex: 1 }}>
            <label className="cj-label">Horário</label>
            <input type="time" className="cj-input" value={hora} onChange={(e) => setHora(e.target.value)} />
          </div>
          <div className="cj-field" style={{ flex: 1 }}>
            <label className="cj-label">Limite diário</label>
            <input className="cj-input" defaultValue="80" type="number" />
          </div>
        </div>

        <div className="cj-card" style={{ background: "var(--green-50)", border: "1px solid var(--green-200)", padding: "var(--space-3) var(--space-4)", marginBottom: "var(--space-5)", display: "flex", gap: 10, alignItems: "flex-start" }}>
          <span style={{ color: "var(--green-600)", flex: "none", marginTop: 1 }}><CJIcon name="clock" size={16} /></span>
          <span style={{ fontSize: "var(--text-xs)", color: "var(--green-800)" }}>Respeita o horário comercial (8h–20h) e não dispara em feriados nacionais.</span>
        </div>

        <Button block size="lg" onClick={criar} leftIcon={<CJIcon name="zap" size={17} />}>Criar régua</Button>
      </div>
    </div>
  );
}

window.AgendamentosScreen = AgendamentosScreen;
