/* CobraJuris — Dashboard / Painel. KPIs, channel mix, recent activity,
   upcoming schedule. Composes DS StatCard, Badge, Table, Button. */

function DashboardScreen({ onNav, onOpenDevedor, onOpenChat }) {
  const DS = window.CobraJurisDesignSystem_4e03fb;
  const { StatCard, Badge, Button } = DS;
  const { devedores, atividade } = useCJ();
  const k = cjKpis(devedores);

  const recentes = devedores.filter((d) => d.status !== "paid").slice(0, 6);
  const taxa = k.total ? Math.round((devedores.filter((d) => d.status === "paid").length / k.total) * 100) : 0;

  return (
    <React.Fragment>
      {/* KPI ROW */}
      <div className="cj-grid cj-grid--4 cj-section">
        <StatCard label="A receber" value={CJ_FMT(k.aReceber)} delta="8,2%" deltaDirection="up" footnote="em aberto" />
        <StatCard label="Recuperado" value={CJ_FMT(k.recuperado)} delta="12,5%" deltaDirection="up" footnote="quitado" />
        <StatCard label="Em atraso" value={String(k.emAtraso)} mono={false} delta="3,1%" deltaDirection="down" footnote="faturas em aberto" />
        <StatCard label="Taxa de quitação" value={taxa + "%"} mono={false} delta="4,0%" deltaDirection="up" footnote={k.total + " faturas"} />
      </div>

      {/* SAÚDE DOS NÚMEROS */}
      <NumberHealthCard onNav={onNav} />

      <div className="cj-grid cj-grid--2 cj-section" style={{ alignItems: "start" }}>
        {/* RECENT ACTIVITY TABLE */}
        <div className="cj-card" style={{ overflow: "hidden" }}>
          <div className="cj-section__head" style={{ padding: "var(--space-5) var(--space-5) var(--space-4)", marginBottom: 0 }}>
            <div>
              <div className="cj-section__title">Cobranças ativas</div>
              <div className="cj-muted" style={{ fontSize: "var(--text-sm)" }}>Faturas com pendência em aberto</div>
            </div>
            <span className="cj-section__link" onClick={() => onNav("devedores")}>
              Ver todos <CJIcon name="arrowRight" size={15} />
            </span>
          </div>
          <table className="cj-table">
            <thead>
              <tr>
                <th>Devedor</th>
                <th>Valor</th>
                <th>Atraso</th>
                <th>Canal</th>
                <th>Situação</th>
              </tr>
            </thead>
            <tbody>
              {recentes.map((d) => {
                const st = CJ_STATUS_LABEL[d.status];
                const cn = CJ_CANAL_LABEL[d.canal];
                return (
                  <tr key={d.id} style={{ cursor: "pointer" }} onClick={() => onOpenDevedor && onOpenDevedor(d)}>
                    <td>
                      <div className="cj-namecell">
                        <div className="cj-avatar cj-avatar--sm">{initials(d.nome)}</div>
                        <div className="cj-stack">
                          <button className="cj-namecell__name cj-namecell__link" style={{ fontSize: "var(--text-sm)" }} onClick={(e) => { e.stopPropagation(); onOpenChat && onOpenChat(d); }} title="Abrir conversa">{shortName(d.nome)}</button>
                          <span className="cj-namecell__meta">{d.id}</span>
                        </div>
                      </div>
                    </td>
                    <td className="cj-td--num">{CJ_FMT(d.valor)}</td>
                    <td>{d.dias > 0 ? <span className="cj-muted">{d.dias} dias</span> : <span className="cj-muted">—</span>}</td>
                    <td>
                      <span className={`cj-canal cj-canal--${d.canal}`}>
                        <CJIcon name={cn.icon} size={15} /> {cn.label}
                      </span>
                    </td>
                    <td><Badge variant={st.badge} dot>{st.label}</Badge></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* RIGHT COLUMN */}
        <div className="cj-stack" style={{ gap: "var(--space-5)" }}>
          {/* Channel mix */}
          <div className="cj-card cj-card--pad">
            <div className="cj-section__title" style={{ marginBottom: "var(--space-4)" }}>Disparos por canal</div>
            <ChannelBar icon="whatsapp" label="WhatsApp" value={9240} pct={68} tone="var(--whatsapp-ink)" />
            <ChannelBar icon="mail" label="E-mail" value={3180} pct={23} tone="var(--info-600)" />
            <ChannelBar icon="smartphone" label="SMS" value={1240} pct={9} tone="var(--ink-500)" />
            <div style={{ borderTop: "1px solid var(--border-subtle)", marginTop: "var(--space-4)", paddingTop: "var(--space-3)", display: "flex", justifyContent: "space-between" }}>
              <span className="cj-muted" style={{ fontSize: "var(--text-sm)" }}>Total no mês</span>
              <span className="tnum" style={{ fontWeight: 700, color: "var(--text-strong)" }}>13.660</span>
            </div>
          </div>

          {/* Live feed */}
          <div className="cj-card cj-card--pad">
            <div className="cj-row" style={{ justifyContent: "space-between", marginBottom: "var(--space-4)" }}>
              <span className="cj-section__title">Atividade recente</span>
              <span className="cj-badge cj-badge--success"><span className="cj-badge__dot"></span>Ao vivo</span>
            </div>
            <div className="cj-stack" style={{ gap: "var(--space-4)" }}>
              {atividade.map((a, i) => {
                const cn = CJ_CANAL_LABEL[a.canal];
                return (
                  <div key={i} className="cj-row cj-gap-3">
                    <span className={`cj-canal cj-canal--${a.canal}`} style={{ width: 26, height: 26, borderRadius: 8, background: "var(--surface-subtle)", display: "inline-flex", alignItems: "center", justifyContent: "center", flex: "none" }}>
                      <CJIcon name={cn.icon} size={14} />
                    </span>
                    <div className="cj-stack" style={{ minWidth: 0, flex: 1 }}>
                      <span style={{ fontSize: "var(--text-sm)", fontWeight: 700, color: "var(--text-strong)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{shortName(a.nome)}</span>
                      <span className="cj-muted" style={{ fontSize: "var(--text-xs)" }}>{a.acao}</span>
                    </div>
                    <span className="cj-muted" style={{ fontSize: "var(--text-xs)", whiteSpace: "nowrap" }}>{a.quando}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* CTA STRIP */}
      <div className="cj-card cj-card--pad" style={{ display: "flex", alignItems: "center", gap: "var(--space-5)", background: "var(--green-900)", border: "none" }}>
        <span style={{ width: 46, height: 46, borderRadius: 12, background: "rgba(255,255,255,0.1)", color: "#fff", display: "inline-flex", alignItems: "center", justifyContent: "center", flex: "none" }}>
          <CJIcon name="upload" size={22} />
        </span>
        <div className="cj-stack" style={{ flex: 1 }}>
          <span style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "var(--text-md)", color: "#fff" }}>Importe a planilha da empresa</span>
          <span style={{ color: "rgba(255,255,255,0.7)", fontSize: "var(--text-sm)" }}>Adicione devedores em massa a partir de um arquivo Excel — a régua começa a rodar automaticamente.</span>
        </div>
        <Button variant="soft" onClick={() => onNav("importar")} leftIcon={<CJIcon name="upload" size={17} />}>Importar planilha</Button>
      </div>
    </React.Fragment>
  );
}

function NumberHealthCard({ onNav }) {
  const CJ_NUMEROS = [
    { id: "n1", numero: "+55 11 99988-1180", apelido: "Linha principal", saude: "ok", enviados: 52, limite: 200, entrega: 98 },
    { id: "n2", numero: "+55 11 95521-7740", apelido: "Linha 2 · acordos", saude: "warming", enviados: 28, limite: 60, entrega: 96 },
    { id: "n3", numero: "+55 11 93310-4402", apelido: "Linha 3 · nova", saude: "risk", enviados: 19, limite: 20, entrega: 81 },
  ];
  const CJ_SAUDE = {
    ok:      { label: "Saudável", tone: "var(--success-600)", bg: "var(--state-paid-bg)", fg: "var(--state-paid-fg)", dot: "#1F8A5B" },
    warming: { label: "Aquecendo", tone: "var(--brass-600)", bg: "var(--brass-50)", fg: "var(--brass-700)", dot: "#BE9233" },
    risk:    { label: "Atenção",  tone: "var(--danger-600)", bg: "var(--state-overdue-bg)", fg: "var(--state-overdue-fg)", dot: "#D64545" },
  };
  const protecoes = [
    { icon: "clock", label: "Cadência humanizada", sub: "1 envio a cada 8–25s" },
    { icon: "refresh", label: "Variação de texto", sub: "Spintax ativo nos modelos" },
    { icon: "checkCircle", label: "Opt-out automático", sub: "“SAIR” remove o contato" },
    { icon: "alert", label: "Pausa por risco", sub: "Para sozinho se a entrega cair" },
  ];
  return (
    <div className="cj-card cj-card--pad cj-section">
      <div className="cj-section__head" style={{ marginBottom: "var(--space-4)" }}>
        <div>
          <div className="cj-section__title">Saúde dos números</div>
          <div className="cj-muted" style={{ fontSize: "var(--text-sm)" }}>Proteção antibloqueio do WhatsApp — cada linha conectada da empresa</div>
        </div>
        <span className="cj-section__link" onClick={() => onNav("config")}>Gerenciar <CJIcon name="arrowRight" size={15} /></span>
      </div>

      <div className="cj-numgrid">
        {CJ_NUMEROS.map((n) => {
          const s = CJ_SAUDE[n.saude];
          const pct = Math.min(100, Math.round((n.enviados / n.limite) * 100));
          return (
            <div key={n.id} className="cj-numcard">
              <div className="cj-numcard__top">
                <span className="cj-numcard__ico"><CJIcon name="whatsapp" size={17} /></span>
                <div className="cj-stack" style={{ minWidth: 0, flex: 1 }}>
                  <span className="cj-numcard__num">{n.numero}</span>
                  <span className="cj-numcard__alias">{n.apelido}</span>
                </div>
                <span className="cj-healthtag" style={{ background: s.bg, color: s.fg }}><span className="cj-healthtag__dot" style={{ background: s.dot }}></span>{s.label}</span>
              </div>
              <div className="cj-numcard__meterhead">
                <span>Limite hoje (aquecimento)</span>
                <span className="tnum" style={{ fontWeight: 700, color: "var(--text-strong)" }}>{n.enviados}/{n.limite}</span>
              </div>
              <div className="cj-progress"><div className="cj-progress__fill" style={{ width: pct + "%", background: s.tone }}></div></div>
              <div className="cj-numcard__foot">
                <span className="cj-muted" style={{ fontSize: "var(--text-xs)" }}>Taxa de entrega</span>
                <span style={{ fontSize: "var(--text-xs)", fontWeight: 700, color: s.tone }}>{n.entrega}%</span>
              </div>
            </div>
          );
        })}
      </div>

      <div className="cj-protrow">
        {protecoes.map((p) => (
          <div key={p.label} className="cj-prot">
            <span className="cj-prot__ico"><CJIcon name={p.icon} size={15} /></span>
            <div className="cj-stack">
              <span className="cj-prot__label">{p.label}</span>
              <span className="cj-prot__sub">{p.sub}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ChannelBar({ icon, label, value, pct, tone }) {
  return (
    <div style={{ marginBottom: "var(--space-4)" }}>
      <div className="cj-row" style={{ justifyContent: "space-between", marginBottom: 6 }}>
        <span className="cj-row cj-gap-2" style={{ fontSize: "var(--text-sm)", fontWeight: 700, color: "var(--text-default)" }}>
          <CJIcon name={icon} size={15} /> {label}
        </span>
        <span className="tnum cj-muted" style={{ fontSize: "var(--text-sm)" }}>{value.toLocaleString("pt-BR")} · {pct}%</span>
      </div>
      <div className="cj-progress"><div className="cj-progress__fill" style={{ width: pct + "%", background: tone }}></div></div>
    </div>
  );
}

function initials(nome) {
  const p = nome.replace(/\b(LTDA|ME|S\/A|EIRELI)\b/gi, "").trim().split(/\s+/);
  return ((p[0]?.[0] || "") + (p[1]?.[0] || "")).toUpperCase();
}
function shortName(nome) {
  if (nome.length <= 26) return nome;
  const p = nome.split(/\s+/);
  return p.length > 2 ? `${p[0]} ${p[1]} ${p[p.length - 1]}` : nome;
}

Object.assign(window, { DashboardScreen, initials, shortName });
