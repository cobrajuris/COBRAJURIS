/* CobraJuris — Importação de planilha. Fluxo real em 3 passos:
   upload (lê o arquivo de verdade) → mapeamento de colunas detectadas →
   confirmação (grava os devedores no store). Suporta .csv nativo e
   .xlsx/.xls via SheetJS carregado sob demanda. */

function ImportacaoScreen({ onNav, pushToast }) {
  const DS = window.CobraJurisDesignSystem_4e03fb;
  const { Button, Badge } = DS;

  const [step, setStep] = React.useState(0); // 0 upload, 1 map, 2 done
  const [over, setOver] = React.useState(false);
  const [busy, setBusy] = React.useState(false);
  const [erro, setErro] = React.useState(null);
  const [file, setFile] = React.useState(null);
  const [parsed, setParsed] = React.useState({ headers: [], rows: [] });
  const [mapping, setMapping] = React.useState([]);
  const [canalPadrao, setCanalPadrao] = React.useState("whatsapp");
  const [dedup, setDedup] = React.useState(true);
  const [resultado, setResultado] = React.useState({ add: 0, total: 0 });
  const inputRef = React.useRef(null);

  const CAMPOS = [
    { v: "nome", label: "Nome / Razão Social" },
    { v: "documento", label: "CPF / CNPJ" },
    { v: "telefone", label: "Telefone (WhatsApp/SMS)" },
    { v: "email", label: "E-mail" },
    { v: "fatura", label: "Nº da Fatura" },
    { v: "valor", label: "Valor do Débito" },
    { v: "vencimento", label: "Data de Vencimento" },
    { v: "ignorar", label: "— Ignorar coluna —" },
  ];

  async function handleFile(f) {
    if (!f) return;
    setBusy(true); setErro(null);
    try {
      const res = await cjParseFile(f);
      if (!res.headers.length || !res.rows.length) throw new Error("A planilha parece vazia ou sem cabeçalho.");
      setFile(f);
      setParsed(res);
      setMapping(res.headers.map((h) => cjGuessField(h)));
      setStep(1);
    } catch (e) {
      setErro(e.message || "Não foi possível ler o arquivo. Verifique o formato (.xlsx, .xls ou .csv).");
    } finally {
      setBusy(false);
    }
  }

  function onDrop(e) {
    e.preventDefault(); setOver(false);
    const f = e.dataTransfer.files && e.dataTransfer.files[0];
    handleFile(f);
  }

  // contagem prévia de linhas válidas (precisa de nome mapeado)
  const previaDevedores = React.useMemo(() => {
    if (step !== 1) return [];
    return cjRowsToDevedores(parsed.headers, parsed.rows, mapping, canalPadrao);
  }, [step, parsed, mapping, canalPadrao]);

  const temNome = mapping.includes("nome");
  const temValor = mapping.includes("valor");

  function finish() {
    let lista = previaDevedores;
    if (dedup) {
      const seen = new Set();
      lista = lista.filter((d) => (seen.has(d.id) ? false : (seen.add(d.id), true)));
    }
    const add = CJStore.addDevedores(lista);
    CJStore.pushNotif({ tipo: "alert", canal: "email", titulo: "Importação concluída", texto: `${add} devedores adicionados à base de cobrança.` });
    setResultado({ add, total: lista.length });
    setStep(2);
    pushToast({ variant: "success", title: "Importação concluída", msg: `${add} devedores adicionados à régua de cobrança.` });
  }

  function reset() {
    setFile(null); setParsed({ headers: [], rows: [] }); setMapping([]); setErro(null); setStep(0);
  }

  return (
    <React.Fragment>
      {/* Steps header */}
      <div className="cj-steps">
        {["Enviar arquivo", "Mapear colunas", "Concluído"].map((label, i) => (
          <React.Fragment key={label}>
            {i > 0 && <div className="cj-step__bar" style={step >= i ? { background: "var(--green-300)" } : null}></div>}
            <div className={"cj-step" + (step === i ? " cj-step--active" : step > i ? " cj-step--done" : "")}>
              <span className="cj-step__num">{step > i ? <CJIcon name="check" size={16} /> : i + 1}</span>
              <span className="cj-step__label">{label}</span>
            </div>
          </React.Fragment>
        ))}
      </div>

      {/* hidden input always present */}
      <input ref={inputRef} type="file" accept=".xlsx,.xls,.csv" style={{ display: "none" }}
        onChange={(e) => handleFile(e.target.files && e.target.files[0])} />

      {/* STEP 0 — upload */}
      {step === 0 && (
        <div style={{ maxWidth: 760 }}>
          <div
            className={"cj-dropzone" + (over ? " cj-dropzone--over" : "")}
            onClick={() => inputRef.current && inputRef.current.click()}
            onDragOver={(e) => { e.preventDefault(); setOver(true); }}
            onDragLeave={() => setOver(false)}
            onDrop={onDrop}
          >
            <span className="cj-dropzone__icon"><CJIcon name={busy ? "refresh" : "sheet"} size={30} className={busy ? "cj-spin" : ""} /></span>
            <div className="cj-dropzone__title">{busy ? "Lendo a planilha…" : "Arraste a planilha aqui ou clique para selecionar"}</div>
            <div className="cj-dropzone__hint">Formatos aceitos: .xlsx, .xls, .csv — leitura real do arquivo, até 5.000 linhas</div>
            <Button variant="secondary" leftIcon={<CJIcon name="upload" size={16} />}>Selecionar arquivo</Button>
          </div>

          {erro && (
            <div className="cj-card cj-card--pad" style={{ marginTop: "var(--space-4)", display: "flex", gap: "var(--space-3)", alignItems: "flex-start", borderColor: "var(--danger-200)", background: "var(--danger-50)" }}>
              <span style={{ color: "var(--danger-600)", flex: "none", marginTop: 2 }}><CJIcon name="alert" size={18} /></span>
              <span style={{ fontSize: "var(--text-sm)", color: "var(--danger-700)" }}>{erro}</span>
            </div>
          )}

          <div className="cj-card cj-card--pad" style={{ marginTop: "var(--space-5)", display: "flex", gap: "var(--space-4)", alignItems: "flex-start" }}>
            <span style={{ color: "var(--info-600)", flex: "none", marginTop: 2 }}><CJIcon name="fileText" size={20} /></span>
            <div className="cj-stack" style={{ gap: 4 }}>
              <span style={{ fontWeight: 700, color: "var(--text-strong)", fontSize: "var(--text-sm)" }}>Não tem um modelo?</span>
              <span className="cj-muted" style={{ fontSize: "var(--text-sm)" }}>Baixe a planilha padrão CobraJuris (.csv) com as colunas já formatadas: nome, documento, telefone, e-mail, fatura, valor e vencimento.</span>
              <a href="#" onClick={(e) => { e.preventDefault(); baixarModelo(); }} style={{ fontSize: "var(--text-sm)", fontWeight: 700, marginTop: 4, display: "inline-flex", alignItems: "center", gap: 4 }}>
                <CJIcon name="download" size={15} /> Baixar modelo .csv
              </a>
            </div>
          </div>
        </div>
      )}

      {/* STEP 1 — mapping */}
      {step === 1 && (
        <div className="cj-grid" style={{ gridTemplateColumns: "1.4fr 1fr", gap: "var(--space-6)", alignItems: "start" }}>
          <div className="cj-stack" style={{ gap: "var(--space-5)" }}>
            <div className="cj-card">
              <div className="cj-filecard">
                <span className="cj-filecard__icon"><CJIcon name="sheet" size={22} /></span>
                <div className="cj-filecard__meta">
                  <div className="cj-filecard__name">{file ? file.name : "planilha"}</div>
                  <div className="cj-filecard__sub">{parsed.rows.length} linhas · {parsed.headers.length} colunas · {file ? Math.max(1, Math.round(file.size / 1024)) + " KB" : ""}</div>
                </div>
                <Badge variant="success" dot>Lido</Badge>
                <button className="cj-iconbtn cj-iconbtn--sm" onClick={reset} title="Remover"><CJIcon name="trash" size={16} /></button>
              </div>
            </div>

            <div className="cj-card cj-card--pad">
              <div className="cj-section__title" style={{ marginBottom: "var(--space-2)" }}>Mapeamento de colunas</div>
              <p className="cj-muted" style={{ fontSize: "var(--text-sm)", marginBottom: "var(--space-4)" }}>Detectamos as colunas automaticamente. Ajuste a correspondência se necessário.</p>
              {parsed.headers.map((h, i) => (
                <div key={i} className="cj-maprow">
                  <span className="cj-mapcol"><span className="cj-mapcol__dot" style={mapping[i] === "ignorar" ? { background: "var(--border-default)" } : null}></span>{h || <em className="cj-muted">coluna {i + 1}</em>}</span>
                  <span className="cj-maparrow"><CJIcon name="arrowRight" size={16} /></span>
                  <select className="cj-select" value={mapping[i]} style={{ height: 36 }}
                    onChange={(e) => setMapping((m) => m.map((x, j) => (j === i ? e.target.value : x)))}>
                    {CAMPOS.map((c) => <option key={c.v} value={c.v}>{c.label}</option>)}
                  </select>
                </div>
              ))}
            </div>

            {/* amostra real */}
            <div className="cj-card cj-card--pad">
              <div className="cj-section__title" style={{ marginBottom: "var(--space-3)" }}>Amostra ({Math.min(3, previaDevedores.length)} de {previaDevedores.length})</div>
              <div className="cj-table-wrap" style={{ border: "1px solid var(--border-subtle)", borderRadius: "var(--radius-md)" }}>
                <table className="cj-table">
                  <thead><tr><th>Nome</th><th>Documento</th><th>Valor</th><th>Atraso</th></tr></thead>
                  <tbody>
                    {previaDevedores.slice(0, 3).map((d, i) => (
                      <tr key={i}>
                        <td style={{ fontWeight: 600 }}>{d.nome}</td>
                        <td className="cj-namecell__meta">{d.doc}</td>
                        <td className="cj-td--num">{CJ_FMT(d.valor)}</td>
                        <td className="cj-muted">{d.dias > 0 ? d.dias + "d" : "—"}</td>
                      </tr>
                    ))}
                    {previaDevedores.length === 0 && <tr><td colSpan={4} className="cj-muted" style={{ textAlign: "center", padding: "var(--space-4)" }}>Mapeie a coluna “Nome” para ver a amostra.</td></tr>}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Right: options + counts */}
          <div className="cj-stack" style={{ gap: "var(--space-5)" }}>
            <div className="cj-card cj-card--pad">
              <div className="cj-section__title" style={{ marginBottom: "var(--space-4)" }}>Opções de importação</div>
              <label className="cj-switch" style={{ justifyContent: "space-between", width: "100%", marginBottom: "var(--space-4)", cursor: "pointer" }}>
                <span>Ignorar duplicados (por fatura)</span>
                <input type="checkbox" checked={dedup} onChange={(e) => setDedup(e.target.checked)} /><span className="cj-switch__track"><span className="cj-switch__thumb"></span></span>
              </label>
              <div className="cj-field" style={{ marginTop: "var(--space-2)" }}>
                <label className="cj-label">Canal padrão de cobrança</label>
                <select className="cj-select" value={canalPadrao} onChange={(e) => setCanalPadrao(e.target.value)}>
                  <option value="whatsapp">WhatsApp</option>
                  <option value="email">E-mail</option>
                  <option value="sms">SMS</option>
                  <option value="auto">Automático (por contato disponível)</option>
                </select>
              </div>
            </div>

            <div className="cj-card cj-card--pad" style={{ background: "var(--green-50)", border: "1px solid var(--green-200)" }}>
              <div className="cj-row" style={{ justifyContent: "space-between" }}>
                <span className="cj-muted" style={{ fontSize: "var(--text-sm)" }}>Linhas no arquivo</span>
                <span style={{ fontWeight: 700, color: "var(--text-strong)" }}>{parsed.rows.length}</span>
              </div>
              <div className="cj-row" style={{ justifyContent: "space-between", marginTop: 8 }}>
                <span className="cj-muted" style={{ fontSize: "var(--text-sm)" }}>Devedores válidos</span>
                <span style={{ fontWeight: 700, color: "var(--green-800)" }}>{previaDevedores.length}</span>
              </div>
              {!temValor && <div className="cj-row" style={{ marginTop: 8 }}><span style={{ fontSize: "var(--text-xs)", color: "var(--warning-700)" }}>Dica: mapeie a coluna “Valor” para registrar os débitos.</span></div>}
            </div>

            <div className="cj-row" style={{ gap: "var(--space-3)" }}>
              <Button variant="secondary" block onClick={reset}>Voltar</Button>
              <Button block onClick={finish} disabled={!temNome || previaDevedores.length === 0} rightIcon={<CJIcon name="check" size={17} />}>Importar {previaDevedores.length}</Button>
            </div>
          </div>
        </div>
      )}

      {/* STEP 2 — done */}
      {step === 2 && (
        <div className="cj-card" style={{ maxWidth: 620, margin: "0 auto" }}>
          <div className="cj-empty">
            <span className="cj-empty__icon" style={{ width: 64, height: 64 }}><CJIcon name="checkCircle" size={30} /></span>
            <div className="cj-empty__title" style={{ fontSize: "var(--text-xl)" }}>Importação concluída</div>
            <p className="cj-empty__text">{resultado.add} devedores foram adicionados{resultado.total > resultado.add ? ` (${resultado.total - resultado.add} duplicados ignorados)` : ""}. Eles já aparecem na lista de devedores e entram na régua automática.</p>
            <div className="cj-row" style={{ gap: "var(--space-3)", marginTop: "var(--space-3)" }}>
              <Button variant="secondary" onClick={reset} leftIcon={<CJIcon name="upload" size={16} />}>Importar outra</Button>
              <Button onClick={() => onNav("devedores")} rightIcon={<CJIcon name="arrowRight" size={16} />}>Ver devedores</Button>
            </div>
          </div>
        </div>
      )}
    </React.Fragment>
  );
}

function baixarModelo() {
  const head = "nome;documento;telefone;email;fatura;valor;vencimento";
  const ex = [
    "João da Silva;123.456.789-00;(11) 98888-0000;joao@email.com;FAT-2026-0001;4.820,50;10/05/2026",
    "Construtora Exemplo LTDA;12.345.678/0001-90;;financeiro@exemplo.com;FAT-2026-0002;28.740,00;01/06/2026",
    "Maria Souza;987.654.321-00;(21) 97777-1111;;FAT-2026-0003;1.290,00;20/05/2026",
  ];
  const csv = [head, ...ex].join("\n");
  const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "modelo_cobrajuris.csv";
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

window.ImportacaoScreen = ImportacaoScreen;
